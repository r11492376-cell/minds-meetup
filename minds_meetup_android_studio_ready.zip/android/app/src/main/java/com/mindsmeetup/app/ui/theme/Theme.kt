package com.mindsmeetup.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Blue and white palette
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF1E88E5),        // Royal Blue
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3F2FD), // Light blue tint
    onPrimaryContainer = Color(0xFF0D47A1),
    secondary = Color(0xFF1976D2),      // Medium deep blue
    onSecondary = Color.White,
    background = Color(0xFFF8F9FA),     // Crisp off-white
    onBackground = Color(0xFF1C1B1F),   // Charcoal
    surface = Color.White,
    onSurface = Color(0xFF1C1B1F),
    surfaceVariant = Color(0xFFECEFF1),  // Slate gray-white tint
    onSurfaceVariant = Color(0xFF37474F),
    error = Color(0xFFD32F2F),          // Danger red
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF90CAF9),
    onPrimary = Color(0xFF0D47A1),
    primaryContainer = Color(0xFF1565C0),
    onPrimaryContainer = Color(0xFFE3F2FD),
    secondary = Color(0xFF64B5F6),
    onSecondary = Color(0xFF0D47A1),
    background = Color(0xFF121212),
    onBackground = Color(0xFFE3E3E3),
    surface = Color(0xFF1E1E1E),
    onSurface = Color(0xFFE3E3E3),
    surfaceVariant = Color(0xFF2C2C2C),
    onSurfaceVariant = Color(0xFFB0BEC5),
    error = Color(0xFFEF5350),
    onError = Color(0xFF5D0000)
)

@Composable
fun MindsMeetupTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
