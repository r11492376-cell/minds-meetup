package com.mindsmeetup.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

// --- DATA STRUCTURES (Models) ---

data class Question(
    val id: String,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctAnswer: String, // "A", "B", "C", "D"
    val explanation: String,
    val difficulty: String, // "Easy", "Medium", "Hard"
    val marks: Int = 4,
    val negativeMarks: Int = 1
)

data class Test(
    val id: String,
    val title: String,
    val category: String, // "Class 10", "Class 11", "Class 12", "JEE", "NEET"
    val subject: String,
    val chapter: String,
    val difficulty: String,
    val questionsCount: Int,
    val totalMarks: Int,
    val durationMinutes: Int,
    val questions: List<Question>
)

data class Attempt(
    val id: String,
    val testId: String,
    val testTitle: String,
    val category: String,
    val subject: String,
    val date: String,
    val score: Int,
    val maxScore: Int,
    val percentage: Float,
    val correctAnswers: Int,
    val wrongAnswers: Int,
    val skippedAnswers: Int,
    val totalQuestions: Int,
    val selectedAnswers: Map<String, String?>,
    val markedForReview: Map<String, Boolean>
)

data class GuidanceMedia(
    val id: String,
    val title: String,
    val description: String,
    val type: String, // "Video" or "Poster"
    val linkOrImage: String
)

// --- NAVIGATION DESTINATIONS ---

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Home : Screen("home")
    object CategorySelection : Screen("category/{catName}") {
        fun createRoute(catName: String) = "category/$catName"
    }
    object TestList : Screen("tests/{category}/{subject}") {
        fun createRoute(category: String, subject: String) = "tests/$category/$subject"
    }
    object TestScreen : Screen("active_test/{testId}") {
        fun createRoute(testId: String) = "active_test/$testId"
    }
    object ResultScreen : Screen("result/{attemptId}") {
        fun createRoute(attemptId: String) = "result/$attemptId"
    }
    object SolutionScreen : Screen("solutions/{attemptId}") {
        fun createRoute(attemptId: String) = "solutions/$attemptId"
    }
    object History : Screen("history")
    object Guidance : Screen("guidance")
    object Admin : Screen("admin")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Splash) }
    var currentCategorySelected by remember { mutableStateOf("") }
    var currentSubjectSelected by remember { mutableStateOf("") }
    var activeTestIdSelected by remember { mutableStateOf("") }
    var activeAttemptIdSelected by remember { mutableStateOf("") }

    // Navigation and state histories
    val navigationStack = remember { mutableStateListOf<Screen>() }
    fun navigateTo(screen: Screen) {
        navigationStack.add(currentScreen)
        currentScreen = screen
    }

    fun navigateBack() {
        if (navigationStack.isNotEmpty()) {
            currentScreen = navigationStack.removeAt(navigationStack.lastIndex)
        } else {
            currentScreen = Screen.Home
        }
    }

    // Attempt list databases (Simulated locally for history)
    val attemptsHistory = remember { mutableStateListOf<Attempt>() }

    // Custom dynamically added tests (admin additions)
    val dynamicTests = remember { mutableStateListOf<Test>() }

    // Combine static sample tests + dynamically added admin tests
    val allTests = remember {
        mutableStateListOf<Test>().apply {
            addAll(getSampleLocalTests())
        }
    }

    // Sync static list if dynamic tests change
    LaunchedEffect(dynamicTests.size) {
        allTests.clear()
        allTests.addAll(getSampleLocalTests())
        allTests.addAll(dynamicTests)
    }

    // Global application screens routing
    Box(modifier = Modifier.fillMaxSize()) {
        when (currentScreen) {
            is Screen.Splash -> {
                SplashScreen(onFinished = {
                    currentScreen = Screen.Home
                })
            }
            is Screen.Home -> {
                HomeScreen(
                    onCategorySelected = { cat ->
                        currentCategorySelected = cat
                        navigateTo(Screen.CategorySelection)
                    },
                    onNavigateToHistory = { navigateTo(Screen.History) },
                    onNavigateToGuidance = { navigateTo(Screen.Guidance) },
                    onNavigateToAdmin = { navigateTo(Screen.Admin) }
                )
            }
            is Screen.CategorySelection -> {
                CategorySelectionScreen(
                    categoryName = currentCategorySelected,
                    onSubjectSelected = { sub ->
                        currentSubjectSelected = sub
                        navigateTo(Screen.TestList)
                    },
                    onBack = { navigateBack() }
                )
            }
            is Screen.TestList -> {
                TestListScreen(
                    category = currentCategorySelected,
                    subject = currentSubjectSelected,
                    tests = allTests.filter { it.category == currentCategorySelected && it.subject == currentSubjectSelected },
                    onStartTest = { testId ->
                        activeTestIdSelected = testId
                        navigateTo(Screen.TestScreen)
                    },
                    onBack = { navigateBack() }
                )
            }
            is Screen.TestScreen -> {
                val activeTest = allTests.find { it.id == activeTestIdSelected }
                if (activeTest != null) {
                    MCQTestScreen(
                        test = activeTest,
                        onTestSubmitted = { attempt ->
                            attemptsHistory.add(attempt)
                            activeAttemptIdSelected = attempt.id
                            // Navigate directly to result screen, clear previous test routes from stack
                            navigationStack.removeIf { it is Screen.TestScreen }
                            currentScreen = Screen.ResultScreen
                        },
                        onBackPress = { navigateBack() }
                    )
                } else {
                    currentScreen = Screen.Home
                }
            }
            is Screen.ResultScreen -> {
                val attempt = attemptsHistory.find { it.id == activeAttemptIdSelected }
                if (attempt != null) {
                    ResultScreen(
                        attempt = attempt,
                        onViewSolutions = {
                            navigateTo(Screen.SolutionScreen)
                        },
                        onBackToHome = {
                            navigationStack.clear()
                            currentScreen = Screen.Home
                        }
                    )
                } else {
                    currentScreen = Screen.Home
                }
            }
            is Screen.SolutionScreen -> {
                val attempt = attemptsHistory.find { it.id == activeAttemptIdSelected }
                val test = allTests.find { it.id == attempt?.testId }
                if (attempt != null && test != null) {
                    SolutionScreen(
                        attempt = attempt,
                        test = test,
                        onBack = { navigateBack() }
                    )
                } else {
                    currentScreen = Screen.Home
                }
            }
            is Screen.History -> {
                ResultHistoryScreen(
                    attempts = attemptsHistory,
                    onViewResult = { attemptId ->
                        activeAttemptIdSelected = attemptId
                        navigateTo(Screen.ResultScreen)
                    },
                    onBack = { navigateBack() }
                )
            }
            is Screen.Guidance -> {
                GuidanceScreen(
                    onBack = { navigateBack() }
                )
            }
            is Screen.Admin -> {
                AdminScreen(
                    onAddTest = { newTest ->
                        dynamicTests.add(newTest)
                    },
                    onBack = { navigateBack() }
                )
            }
        }
    }
}

// --- SCREEN IMPLEMENTATIONS ---

// 1. SPLASH SCREEN
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(2200) // Delay for high-fidelity splash screen sensation
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E88E5)), // Blue and white core
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // Elegant Brain/Idea Meetup Icon
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(96.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Mind's Meetup",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Free Test Series for Class 10, 11, 12, JEE & NEET",
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.85f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 32.dp)
            )
            Spacer(modifier = Modifier.height(96.dp))
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 3.dp,
                modifier = Modifier.size(36.dp)
            )
        }
    }
}

// 2. HOME SCREEN
@Composable
fun HomeScreen(
    onCategorySelected: (String) -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToGuidance: () -> Unit,
    onNavigateToAdmin: () -> Unit
) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = {
                    Text(
                        "Mind's Meetup",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = Color(0xFF1E88E5)
                ),
                actions = {
                    IconButton(onClick = onNavigateToAdmin) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Admin panel",
                            tint = Color.White
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF8F9FA))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Banner Card (Incredibly polished welcome message)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE3F2FD)),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text(
                            text = "Welcome to Mind's Meetup",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0D47A1)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Free Premium Quality Test Series / निशुल्क उच्च गुणवत्ता टेस्ट सीरीज़",
                            fontSize = 14.sp,
                            color = Color(0xFF1E88E5),
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Empowering students preparing for Boards, JEE & NEET exams with curated question patterns, timer formats, detailed results and explanations.",
                            fontSize = 13.sp,
                            color = Color.Gray,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // Quick Menu Header
            item {
                Text(
                    text = "Select Course / कोर्स चुनें",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF37474F)
                )
            }

            // Category Items Grid (Class 10, 11, 12, JEE, NEET)
            val categories = listOf(
                Pair("Class 10", Icons.Default.Star),
                Pair("Class 11", Icons.Default.List),
                Pair("Class 12", Icons.Default.Build),
                Pair("JEE", Icons.Default.PlayArrow),
                Pair("NEET", Icons.Default.Favorite)
            )

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    categories.forEach { (catName, icon) ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onCategorySelected(catName) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE3F2FD))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFE3F2FD)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = Color(0xFF1E88E5)
                                    )
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = catName,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0D47A1)
                                    )
                                    Text(
                                        text = getSubtextForCategory(catName),
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = null,
                                    tint = Color.LightGray
                                )
                            }
                        }
                    }
                }
            }

            // Extra Actions Divider
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "More Recourse / अतिरिक्त विकल्प",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF37474F)
                )
            }

            // Buttons row: Guidance Videos, Posters, Result History
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onNavigateToGuidance,
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Videos", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = onNavigateToHistory,
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D47A1)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("History", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// 3. CLASS & SUBJECT SELECTION
@Composable
fun CategorySelectionScreen(
    categoryName: String,
    onSubjectSelected: (String) -> Unit,
    onBack: () -> Unit
) {
    val subjects = getSubjectsForCategory(categoryName)

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text(categoryName, fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color(0xFF1E88E5))
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF8F9FA))
                .padding(16.dp)
        ) {
            Text(
                text = "Select Course Subject / विषय चुनें",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0D47A1),
                modifier = Modifier.padding(bottom = 16.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(subjects) { subject ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSubjectSelected(subject) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE3F2FD))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE3F2FD)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = subject.first().toString(),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E88E5)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = getSubjectTranslations(subject),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF37474F)
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = null,
                                tint = Color.LightGray
                            )
                        }
                    }
                }
            }
        }
    }
}

// 4. TEST LIST SCREEN
@Composable
fun TestListScreen(
    category: String,
    subject: String,
    tests: List<Test>,
    onStartTest: (String) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("$category: $subject", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color(0xFF1E88E5))
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF8F9FA))
                .padding(16.dp)
        ) {
            Text(
                text = "Available Exams / परीक्षा सूची",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0D47A1),
                modifier = Modifier.padding(bottom = 12.dp)
            )

            if (tests.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.List, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color.LightGray)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "No test sets generated for this topic yet!\nYou can add custom mock tests in the Admin Panel.",
                            textAlign = TextAlign.Center,
                            color = Color.Gray,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(tests) { test ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE3F2FD)),
                            elevation = CardDefaults.cardElevation(2.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = getDifficultyColor(test.difficulty).copy(alpha = 0.12f),
                                        modifier = Modifier.clip(RoundedCornerShape(4.dp))
                                    ) {
                                        Text(
                                            text = test.difficulty,
                                            color = getDifficultyColor(test.difficulty),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            modifier = Modifier.size(12.dp),
                                            tint = Color.Gray
                                        )
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text(
                                            "${test.durationMinutes} Mins",
                                            fontSize = 12.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = test.title,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF37474F)
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = "Chapter: ${test.chapter}",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Spacer(modifier = Modifier.height(14.dp))
                                Divider(color = Color(0xFFECEFF1))
                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            "Questions: ${test.questionsCount}",
                                            fontSize = 12.sp,
                                            color = Color.DarkGray
                                        )
                                        Text(
                                            "Total Marks: ${test.totalMarks}",
                                            fontSize = 12.sp,
                                            color = Color.DarkGray,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }

                                    Button(
                                        onClick = { onStartTest(test.id) },
                                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5))
                                    ) {
                                        Text("Start Test", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 5. MCQ TEST SCREEN WITH COUNTDOWN
@Composable
fun MCQTestScreen(
    test: Test,
    onTestSubmitted: (Attempt) -> Unit,
    onBackPress: () -> Unit
) {
    var currentQuestionIndex by remember { mutableStateOf(0) }
    // Store selected option ("A", "B", "C", "D" or null)
    val selectedAnswers = remember { mutableStateMapOf<String, String?>() }
    val markedForReview = remember { mutableStateMapOf<String, Boolean>() }

    // Init keys
    LaunchedEffect(test) {
        test.questions.forEach {
            if (!selectedAnswers.containsKey(it.id)) selectedAnswers[it.id] = null
            if (!markedForReview.containsKey(it.id)) markedForReview[it.id] = false
        }
    }

    // Countdown Timer logic (durationMinutes * 60)
    var timeLeftSeconds by remember { mutableStateOf(test.durationMinutes * 60) }
    LaunchedEffect(Unit) {
        while (timeLeftSeconds > 0) {
            delay(1000)
            timeLeftSeconds--
        }
        // Auto-submit on expiration
        if (timeLeftSeconds == 0) {
            // Auto submit
            val scoreResults = computeScore(test, selectedAnswers)
            val format = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
            onTestSubmitted(
                Attempt(
                    id = UUID.randomUUID().toString(),
                    testId = test.id,
                    testTitle = test.title,
                    category = test.category,
                    subject = test.subject,
                    date = format.format(Date()),
                    score = scoreResults.first,
                    maxScore = test.totalMarks,
                    percentage = (scoreResults.first.toFloat() / test.totalMarks.toFloat()) * 100f,
                    correctAnswers = scoreResults.second,
                    wrongAnswers = scoreResults.third,
                    skippedAnswers = scoreResults.fourth,
                    totalQuestions = test.questions.size,
                    selectedAnswers = selectedAnswers.toMap(),
                    markedForReview = markedForReview.toMap()
                )
            )
        }
    }

    val currentQuestion = test.questions.getOrNull(currentQuestionIndex)

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Question ${currentQuestionIndex + 1}/${test.questions.size}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Surface(
                            color = Color.White.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            Text(
                                text = formatTime(timeLeftSeconds),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackPress) {
                        Icon(Icons.Default.Close, contentDescription = "Quit", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color(0xFF1E88E5))
            )
        }
    ) { paddingValues ->
        if (currentQuestion != null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(Color(0xFFF8F9FA))
                    .padding(16.dp)
            ) {
                // Bottom control row elements
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isMarked = markedForReview[currentQuestion.id] ?: false
                    Text(
                        text = "Marks: +4 | -1",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.SemiBold
                    )

                    Button(
                        onClick = { markedForReview[currentQuestion.id] = !isMarked },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isMarked) Color(0xFFFFB300) else Color(0xFFECEFF1)
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(
                            imageVector = if (isMarked) Icons.Default.Star else Icons.Default.List,
                            contentDescription = null,
                            tint = if (isMarked) Color.White else Color.DarkGray,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isMarked) "Marked" else "Mark for Review",
                            fontSize = 11.sp,
                            color = if (isMarked) Color.White else Color.DarkGray,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Question Text Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFECEFF1))
                ) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        item {
                            Text(
                                text = currentQuestion.questionText,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF37474F),
                                lineHeight = 22.sp
                            )
                            Spacer(modifier = Modifier.height(24.dp))
                        }

                        // Options A, B, C, D
                        val options = listOf(
                            Pair("A", currentQuestion.optionA),
                            Pair("B", currentQuestion.optionB),
                            Pair("C", currentQuestion.optionC),
                            Pair("D", currentQuestion.optionD)
                        )

                        items(options) { (optionCode, optionText) ->
                            val isSelected = selectedAnswers[currentQuestion.id] == optionCode
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .clickable {
                                        // Toggle or select
                                        if (isSelected) {
                                            selectedAnswers[currentQuestion.id] = null
                                        } else {
                                            selectedAnswers[currentQuestion.id] = optionCode
                                        }
                                    },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) Color(0xFFE3F2FD) else Color.White
                                ),
                                border = BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) Color(0xFF1E88E5) else Color(0xFFECEFF1)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isSelected) Color(0xFF1E88E5) else Color(0xFFECEFF1)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = optionCode,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else Color.DarkGray,
                                            fontSize = 13.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = optionText,
                                        fontSize = 14.sp,
                                        color = if (isSelected) Color(0xFF0D47A1) else Color(0xFF37474F),
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Panel Buttons (Prev, Next, Submit)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            if (currentQuestionIndex > 0) {
                                currentQuestionIndex--
                            }
                        },
                        enabled = currentQuestionIndex > 0
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Previous", fontWeight = FontWeight.Bold)
                        }
                    }

                    if (currentQuestionIndex == test.questions.size - 1) {
                        Button(
                            onClick = {
                                val scoreResults = computeScore(test, selectedAnswers)
                                val format = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
                                onTestSubmitted(
                                    Attempt(
                                        id = UUID.randomUUID().toString(),
                                        testId = test.id,
                                        testTitle = test.title,
                                        category = test.category,
                                        subject = test.subject,
                                        date = format.format(Date()),
                                        score = scoreResults.first,
                                        maxScore = test.totalMarks,
                                        percentage = (scoreResults.first.toFloat() / test.totalMarks.toFloat()) * 100f,
                                        correctAnswers = scoreResults.second,
                                        wrongAnswers = scoreResults.third,
                                        skippedAnswers = scoreResults.fourth,
                                        totalQuestions = test.questions.size,
                                        selectedAnswers = selectedAnswers.toMap(),
                                        markedForReview = markedForReview.toMap()
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Submit Test / अंतिम जमा करें", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = {
                                if (currentQuestionIndex < test.questions.size - 1) {
                                    currentQuestionIndex++
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5))
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Next", fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// 6. RESULT SUMMARY SCREEN
@Composable
fun ResultScreen(
    attempt: Attempt,
    onViewSolutions: () -> Unit,
    onBackToHome: () -> Unit
) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Result / परीक्षा परिणाम", fontWeight = FontWeight.Bold, color = Color.White) },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color(0xFF1E88E5))
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF8F9FA))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE3F2FD))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Score Statement",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${attempt.score} / ${attempt.maxScore}",
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (attempt.score >= attempt.maxScore * 0.4) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = String.format("%.1f%% Successful", attempt.percentage),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1E88E5)
                        )

                        Spacer(modifier = Modifier.height(18.dp))
                        Divider(color = Color(0xFFECEFF1))
                        Spacer(modifier = Modifier.height(18.dp))

                        // Stats Grid (Correct, Wrong, Skipped)
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFE8F5E9)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF2E7D32))
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Correct", fontSize = 12.sp, color = Color.Gray)
                                Text("${attempt.correctAnswers}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                            }

                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFFEBEE)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFFC62828))
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Wrong", fontSize = 12.sp, color = Color.Gray)
                                Text("${attempt.wrongAnswers}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                            }

                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFECEFF1)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.Gray)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Skipped", fontSize = 12.sp, color = Color.Gray)
                                Text("${attempt.skippedAnswers}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                            }
                        }
                    }
                }
            }

            // Performance Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFECEFF1))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "General Performance Indicator",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF37474F)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = attempt.percentage / 100f,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (attempt.percentage >= 75) Color(0xFF2E7D32) else if (attempt.percentage >= 40) Color(0xFFFFB300) else Color(0xFFD32F2F),
                            trackColor = Color(0xFFECEFF1)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (attempt.percentage >= 75) "Outstanding! You are highly ready for Boards/JEE/NEET."
                                   else if (attempt.percentage >= 40) "Good effort. Analyze the solution answers to improve ratings."
                                   else "Need substantial practice. Review subjects and reapply.",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            // Buttons: Solutions, Back home
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = onViewSolutions,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("View Solutions & Explanations", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onBackToHome,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        border = BorderStroke(1.dp, Color(0xFF1E88E5)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Back to Home Dashboard", fontSize = 15.sp, color = Color(0xFF1E88E5), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// 7. SOLUTION REVIEW SCREEN
@Composable
fun SolutionScreen(
    attempt: Attempt,
    test: Test,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Solution Paper", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color(0xFF1E88E5))
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF8F9FA))
                .padding(16.dp)
        ) {
            Text(
                text = "${test.questions.size} Solutions & Explanations",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0D47A1),
                modifier = Modifier.padding(bottom = 12.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(test.questions.size) { index ->
                    val q = test.questions[index]
                    val userSelected = attempt.selectedAnswers[q.id]
                    val isCorrect = userSelected == q.correctAnswer

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFECEFF1))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Question ${index + 1}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color.Gray
                                )

                                Surface(
                                    color = if (userSelected == null) Color(0xFFECEFF1)
                                            else if (isCorrect) Color(0xFFE8F5E9)
                                            else Color(0xFFFFEBEE),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (userSelected == null) "Skipped"
                                               else if (isCorrect) "Correct +4"
                                               else "Wrong -1",
                                        color = if (userSelected == null) Color.DarkGray
                                                else if (isCorrect) Color(0xFF2E7D32)
                                                else Color(0xFFC62828),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = q.questionText,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF37474F)
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Options rendering
                            SolutionOptionRow("A", q.optionA, q.correctAnswer, userSelected)
                            SolutionOptionRow("B", q.optionB, q.correctAnswer, userSelected)
                            SolutionOptionRow("C", q.optionC, q.correctAnswer, userSelected)
                            SolutionOptionRow("D", q.optionD, q.correctAnswer, userSelected)

                            Spacer(modifier = Modifier.height(14.dp))
                            Divider(color = Color(0xFFECEFF1))
                            Spacer(modifier = Modifier.height(14.dp))

                            // Explanation Block
                            Text(
                                "Correct Option: [${q.correctAnswer}]",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Explanation / व्याख्या:\n${q.explanation}",
                                fontSize = 13.sp,
                                color = Color.DarkGray,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SolutionOptionRow(
    optionCode: String,
    optionText: String,
    correctAnswer: String,
    userSelected: String?
) {
    val isCorrectOption = optionCode == correctAnswer
    val isUserSelected = optionCode == userSelected
    
    val containerColor = if (isCorrectOption) Color(0xFFE8F5E9) // True ans is green
                          else if (isUserSelected) Color(0xFFFFEBEE) // User wrong selection is red
                          else Color.White
    
    val borderColor = if (isCorrectOption) Color(0xFF2E7D32)
                      else if (isUserSelected) Color(0xFFC62828)
                      else Color(0xFFECEFF1)

    val chipColor = if (isCorrectOption) Color(0xFF2E7D32)
                    else if (isUserSelected) Color(0xFFC62828)
                    else Color(0xFFECEFF1)

    val chipTextColor = if (isCorrectOption || isUserSelected) Color.White else Color.DarkGray

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(chipColor),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = optionCode,
                    fontWeight = FontWeight.Bold,
                    color = chipTextColor,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = optionText,
                fontSize = 13.sp,
                color = Color(0xFF37474F)
            )
            Spacer(modifier = Modifier.weight(1f))
            if (isCorrectOption) {
                Icon(Icons.Default.Check, contentDescription = "Correct Answer", tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
            } else if (isUserSelected) {
                Icon(Icons.Default.Close, contentDescription = "Your Answer", tint = Color(0xFFC62828), modifier = Modifier.size(16.dp))
            }
        }
    }
}

// 8. RESULT HISTORY SCREEN
@Composable
fun ResultHistoryScreen(
    attempts: List<Attempt>,
    onViewResult: (String) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Attempts History", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color(0xFF1E88E5))
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF8F9FA))
                .padding(16.dp)
        ) {
            Text(
                text = "Past Test Performances / पूर्व परीक्षा इतिहास",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0D47A1),
                modifier = Modifier.padding(bottom = 12.dp)
            )

            if (attempts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color.LightGray)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "You haven\'t attempted any test yet!\nSelect a subject and run mock sets.",
                            textAlign = TextAlign.Center,
                            color = Color.Gray,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(attempts) { item ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onViewResult(item.id) },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE3F2FD))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.category,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1E88E5)
                                    )
                                    Text(
                                        text = item.date,
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = item.testTitle,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF37474F)
                                )

                                Spacer(modifier = Modifier.height(10.dp))
                                Divider(color = Color(0xFFECEFF1))
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Score: ${item.score}/${item.maxScore}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                                        Text("Correct: ${item.correctAnswers}", fontSize = 12.sp, color = Color(0xFF2E7D32))
                                        Text("Wrong: ${item.wrongAnswers}", fontSize = 12.sp, color = Color(0xFFC62828))
                                    }

                                    Text(
                                        text = String.format("%.1f%%", item.percentage),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0D47A1)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 9. GUIDANCE MEDIA SCREEN (VIDEOS & POSTERS)
@Composable
fun GuidanceScreen(onBack: () -> Unit) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Videos, 1 = Posters
    val tabs = listOf("Guidance Videos (वीडियो)", "Revision Posters (पोस्टर)")

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Guidance & Revision Hub", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color(0xFF1E88E5))
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF8F9FA))
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = Color(0xFF1E88E5)
            ) {
                tabs.forEachIndexed { index, text ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                    )
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                if (selectedTab == 0) {
                    val videos = getSampleVideos()
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        items(videos) { vid ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFECEFF1))
                            ) {
                                Column {
                                    // Simulated Image Thumbnail Placeholder
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(140.dp)
                                            .background(Color(0xFFECEFF1)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color(0xFF1E88E5))
                                    }

                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text(
                                            text = vid.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = Color(0xFF37474F)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = vid.description,
                                            fontSize = 12.sp,
                                            color = Color.Gray,
                                            lineHeight = 16.sp
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Button(
                                            onClick = { /* Open Video Link */ },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Watch Premium Video (मुफ़्त देखें)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    val posters = getSamplePosters()
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(posters) { poster ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFECEFF1))
                            ) {
                                Column {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(100.dp)
                                            .background(Color(0xFFE3F2FD)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Menu, contentDescription = null, tint = Color(0xFF1E88E5))
                                    }

                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = poster.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFF37474F),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = poster.description,
                                            fontSize = 11.sp,
                                            color = Color.Gray,
                                            maxLines = 2,
                                            lineHeight = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 10. ADMIN PANEL PLACEHOLDER (UI Only)
@Composable
fun AdminScreen(
    onAddTest: (Test) -> Unit,
    onBack: () -> Unit
) {
    var adminLogMessage by remember { mutableStateOf("") }
    var inputTitle by remember { mutableStateOf("") }
    var inputCategory by remember { mutableStateOf("Class 10") }
    var inputSubject by remember { mutableStateOf("Science") }
    var inputChapter by remember { mutableStateOf("") }
    var inputDuration by remember { mutableStateOf("10") }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Admin Panel (Placeholder)", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color(0xFF0D47A1))
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF8F9FA))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFECEFF1))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Future DB Synchronization Panel",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0D47A1)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "This screen acts as a local UI placeholder for admin controls. Content is ready for Firebase API routes.",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            // Simple Admin Add-Test Form Demo
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE3F2FD))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Simulated Add New Test Core / नई परीक्षा जोड़ें",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color(0xFF37474F)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = inputTitle,
                                onValueChange = { inputTitle = it },
                                label = { Text("Test Title (परीक्षा का नाम)") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Category:", fontSize = 11.sp, color = Color.Gray)
                                    // Dropdowns mock
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { /* Select from cat list */ }
                                            .background(Color(0xFFECEFF1))
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(inputCategory, fontSize = 13.sp)
                                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(14.dp))
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Subject:", fontSize = 11.sp, color = Color.Gray)
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { /* Select from sub list */ }
                                            .background(Color(0xFFECEFF1))
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(inputSubject, fontSize = 13.sp)
                                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = inputChapter,
                                onValueChange = { inputChapter = it },
                                label = { Text("Chapter/Topic") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = inputDuration,
                                onValueChange = { inputDuration = it },
                                label = { Text("Duration (Minutes)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                if (inputTitle.isNotEmpty() && inputChapter.isNotEmpty()) {
                                    // Create a mock test with 10 copy questions of class 10 to simulate add test
                                    val newTest = Test(
                                        id = "dyn_" + UUID.randomUUID().toString(),
                                        title = inputTitle,
                                        category = inputCategory,
                                        subject = inputSubject,
                                        chapter = inputChapter,
                                        difficulty = "Medium",
                                        questionsCount = 10,
                                        totalMarks = 40,
                                        durationMinutes = inputDuration.toIntOrNull() ?: 10,
                                        questions = getSampleLocalTests().first().questions // Copy sample questions
                                    )
                                    onAddTest(newTest)
                                    adminLogMessage = "Successfully created custom test locally: \"$inputTitle\"!"
                                    inputTitle = ""
                                    inputChapter = ""
                                } else {
                                    adminLogMessage = "Error: Title and Chapter are required fields."
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D47A1))
                        ) {
                            Text("Mock Save Test in RAM (सहेजें)", fontWeight = FontWeight.Bold)
                        }

                        if (adminLogMessage.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(adminLogMessage, color = Color(0xFF2E7D32), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            // Quick UI Buttons (Add Question, Upload CSV, Add Poster, Add Video, Manage Tests)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFECEFF1))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Admin Panel Placeholders (UI Only)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color(0xFF37474F)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val actions = listOf(
                            "Add Question / प्रश्न जोड़ें",
                            "Upload CSV File / सीएसवी अपलोड",
                            "Add Revision Poster / पोस्टर जोड़ें",
                            "Add Guidance Video / वीडियो जोड़ें",
                            "Manage Active Tests / टेस्ट प्रबंधित करें"
                        )

                        actions.forEach { action ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        adminLogMessage = "Action toggled: \"$action\" clicked! Form fields will load when Firebase Sync is enabled."
                                    }
                                    .padding(vertical = 12.dp, horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(action, fontSize = 13.sp, color = Color.DarkGray)
                                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                            }
                            Divider(color = Color(0xFFECEFF1))
                        }
                    }
                }
            }
        }
    }
}

// --- HELPER TRANSLATORS AND CALCULATORS ---

fun getSubtextForCategory(category: String): String {
    return when (category) {
        "Class 10" -> "Science, Maths, Social, English, Hindi"
        "Class 11" -> "Physics, Chemistry, Maths, Biology"
        "Class 12" -> "Physics, Chemistry, Maths, Biology"
        "JEE" -> "Physics, Chemistry, Maths"
        "NEET" -> "Physics, Chemistry, Biology"
        else -> ""
    }
}

fun getSubjectsForCategory(category: String): List<String> {
    return when (category) {
        "Class 10" -> listOf("Science", "Maths", "Social Science", "English", "Hindi")
        "Class 11" -> listOf("Physics", "Chemistry", "Maths", "Biology")
        "Class 12" -> listOf("Physics", "Chemistry", "Maths", "Biology")
        "JEE" -> listOf("Physics", "Chemistry", "Maths")
        "NEET" -> listOf("Physics", "Chemistry", "Biology")
        else -> emptyList()
    }
}

fun getSubjectTranslations(subj: String): String {
    return when (subj) {
        "Science" -> "Science (विज्ञान)"
        "Maths" -> "Maths (गणित)"
        "Social Science" -> "Social Science (सामाजिक विज्ञान)"
        "English" -> "English (अंग्रेजी)"
        "Hindi" -> "Hindi (हिंदी)"
        "Physics" -> "Physics (भौतिक विज्ञान)"
        "Chemistry" -> "Chemistry (रसायन विज्ञान)"
        "Biology" -> "Biology (जीव विज्ञान)"
        else -> subj
    }
}

fun getDifficultyColor(diff: String): Color {
    return when (diff) {
        "Easy" -> Color(0xFF2E7D32)
        "Medium" -> Color(0xFFFFB300)
        "Hard" -> Color(0xFFD32F2F)
        else -> Color.Gray
    }
}

fun formatTime(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format("%02d:%02d", m, s)
}

// Computes standard scoring system (+4 for correct, -1 for wrong, 0 for skipped/unanswered)
fun computeScore(test: Test, selectedAnswers: Map<String, String?>): Tuple4<Int, Int, Int, Int> {
    var score = 0
    var correct = 0
    var wrong = 0
    var skipped = 0

    test.questions.forEach { q ->
        val userAns = selectedAnswers[q.id]
        if (userAns == null) {
            skipped++
        } else if (userAns == q.correctAnswer) {
            correct++
            score += 4
        } else {
            wrong++
            score -= 1
        }
    }
    return Tuple4(score, correct, wrong, skipped)
}

// Custom Helper Class
data class Tuple4<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)


// --- HARCODED LOCAL STATIC SAMPLE DATA COPIES FOR NATIVE COMPILING WALLET ---

fun getSampleLocalTests(): List<Test> {
    // Exact match of sample tests returned as clean list
    return listOf(
        Test(
            id = "t1",
            title = "Class 10 Science: Chemical Reactions & Acids",
            category = "Class 10",
            subject = "Science",
            chapter = "Ch 1 & 2: Chemical Reactions; Acids, Salts",
            difficulty = "Medium",
            questionsCount = 10,
            totalMarks = 40,
            durationMinutes = 10,
            questions = listOf(
                Question(
                    id = "t1_q1",
                    questionText = "What is the chemical formula of Slaked Lime (बुझे हुए चूने का रासायनिक सूत्र क्या है)?",
                    optionA = "CaO", optionB = "Ca(OH)₂", optionC = "CaCO₃", optionD = "CaCl₂",
                    correctAnswer = "B", explanation = "Slaked Lime is Calcium Hydroxide.", difficulty = "Easy"
                ),
                Question(
                    id = "t1_q2",
                    questionText = "Why is respiration considered an exothermic reaction?",
                    optionA = "Heat is absorbed", optionB = "Energy/heat is released", optionC = "Decomposes water", optionD = "None",
                    correctAnswer = "B", explanation = "Respiration releases energy making it exothermic.", difficulty = "Medium"
                ),
                Question(
                    id = "t1_q3",
                    questionText = "Which acid is naturally present in Tamarind?",
                    optionA = "Tartaric Acid", optionB = "Citric Acid", optionC = "Oxalic Acid", optionD = "Methanoic Acid",
                    correctAnswer = "A", explanation = "Tamarind contains Tartaric Acid.", difficulty = "Easy"
                ),
                Question(
                    id = "t1_q4",
                    questionText = "What happens when Quick Lime reacts with water rapidly?",
                    optionA = "Heat is absorbed", optionB = "No change", optionC = "Slaked Lime forms with massive heat", optionD = "O₂ gas released",
                    correctAnswer = "C", explanation = "Exothermic combination reaction yielding slaked lime and heat.", difficulty = "Medium"
                ),
                Question(
                    id = "t1_q5",
                    questionText = "What is the pH value of pure neutral water?",
                    optionA = "0", optionB = "7", optionC = "14", optionD = "1",
                    correctAnswer = "B", explanation = "Neutral water pH is exactly 7.", difficulty = "Easy"
                ),
                Question(
                    id = "t1_q6",
                    questionText = "What color does Phenolphthalein indicator turn in basic solution?",
                    optionA = "Pink", optionB = "Yellow", optionC = "Deep Red", optionD = "Colorless",
                    correctAnswer = "A", explanation = "Phenolphthalein turns pink under basic conditions.", difficulty = "Medium"
                ),
                Question(
                    id = "t1_q7",
                    questionText = "Iron rusting is fundamentally which change?",
                    optionA = "Decomposition", optionB = "Oxidation/Redox", optionC = "Displacement", optionD = "Endothermic",
                    correctAnswer = "B", explanation = "Iron reacts with oxygen and moisture to oxidize.", difficulty = "Easy"
                ),
                Question(
                    id = "t1_q8",
                    questionText = "What is the approximate pH of healthy human blood?",
                    optionA = "6.0", optionB = "7.4", optionC = "8.5", optionD = "5.5",
                    correctAnswer = "B", explanation = "Blood maintains narrow pH at 7.4.", difficulty = "Medium"
                ),
                Question(
                    id = "t1_q9",
                    questionText = "Tooth decay initiates below what pH of mouth?",
                    optionA = "7.0", optionB = "5.5", optionC = "6.5", optionD = "8.0",
                    correctAnswer = "B", explanation = "Enamel corrodes below pH 5.5.", difficulty = "Hard"
                ),
                Question(
                    id = "t1_q10",
                    questionText = "Common name of Sodium Carbonate Decahydrate?",
                    optionA = "Baking Soda", optionB = "Washing Soda", optionC = "Bleaching Powder", optionD = "Plaster of Paris",
                    correctAnswer = "B", explanation = "Na₂CO₃·10H₂O is Washing Soda.", difficulty = "Hard"
                )
            )
        ),
        Test(
            id = "t2",
            title = "Class 11 Physics: Kinematics and Mechanics",
            category = "Class 11",
            subject = "Physics",
            chapter = "Ch 3 & 5: Motion & Laws of Motion",
            difficulty = "Medium",
            questionsCount = 10,
            totalMarks = 40,
            durationMinutes = 10,
            questions = listOf(
                Question(
                    id = "t2_q1",
                    questionText = "Slope of Velocity-Time graph represents?",
                    optionA = "Distance", optionB = "Displacement", optionC = "Acceleration", optionD = "Force",
                    correctAnswer = "C", explanation = "Slope dv/dt represents acceleration.", difficulty = "Easy"
                ),
                Question(
                    id = "t2_q2",
                    questionText = "Newton's First Law is also known as?",
                    optionA = "Law of Inertia", optionB = "Law of Linear Momentum", optionC = "Law of Action-Reaction", optionD = "Law of Gravitation",
                    correctAnswer = "A", explanation = "First Law is the Law of Inertia.", difficulty = "Easy"
                ),
                Question(
                    id = "t2_q3",
                    questionText = "Car starts from rest (u=0) with acceleration 2 m/s². Displacement in 5s?",
                    optionA = "10 meters", optionB = "25 meters", optionC = "50 meters", optionD = "5 meters",
                    correctAnswer = "B", explanation = "s = ut + 0.5at² = 25m.", difficulty = "Medium"
                ),
                Question(
                    id = "t2_q4",
                    questionText = "A rolling ball slows to rest due to?",
                    optionA = "No active force", optionB = "Velocity proportional to force", optionC = "Floor frictional force", optionD = "Gravity",
                    correctAnswer = "C", explanation = "Frictional force opposes relative motion.", difficulty = "Easy"
                ),
                Question(
                    id = "t2_q5",
                    questionText = "Quantity sharing same unit/dimension as Impulse?",
                    optionA = "Force", optionB = "Linear Momentum", optionC = "Work", optionD = "Power",
                    correctAnswer = "B", explanation = "Impulse is change of linear momentum.", difficulty = "Medium"
                ),
                Question(
                    id = "t2_q6",
                    questionText = "g on Earth does NOT depend on?",
                    optionA = "Mass of falling body", optionB = "Radius of Earth", optionC = "Mass of Earth", optionD = "G",
                    correctAnswer = "A", explanation = "g is independent of mass of falling object.", difficulty = "Medium"
                ),
                Question(
                    id = "t2_q7",
                    questionText = "Formula of Centripetal Force?",
                    optionA = "mv/r", optionB = "mv²/r", optionC = "mv²r", optionD = "mvr²",
                    correctAnswer = "B", explanation = "Centripetal acceleration is v²/r.", difficulty = "Easy"
                ),
                Question(
                    id = "t2_q8",
                    questionText = "Rocket propulsion behaves according to?",
                    optionA = "Mass conservation", optionB = "Energy conservation", optionC = "Conservation of linear momentum", optionD = "Angular momentum conservation",
                    correctAnswer = "C", explanation = "Propulsion operates on conservation of linear momentum.", difficulty = "Medium"
                ),
                Question(
                    id = "t2_q9",
                    questionText = "Projection angle for maximum horizontal range is?",
                    optionA = "30°", optionB = "45°", optionC = "60°", optionD = "90°",
                    correctAnswer = "B", explanation = "R is maximum at 45°.", difficulty = "Medium"
                ),
                Question(
                    id = "t2_q10",
                    questionText = "Static Friction is?",
                    optionA = "Constant", optionB = "Self-adjusting", optionC = "Independent of roughness", optionD = "Equal to dynamic friction",
                    correctAnswer = "B", explanation = "Self-adjusts to balance external forces.", difficulty = "Hard"
                )
            )
        )
    )
}

fun getSampleVideos(): List<GuidanceMedia> {
    return listOf(
        GuidanceMedia("v1", "Crack JEE/NEET 1-Year Plan", "Plan schedules and material guidelines.", "Video", "https://youtube.com"),
        GuidanceMedia("v2", "Last 3 Months Board Prep", "P presentation guides for boards.", "Video", "https://youtube.com")
    )
}

fun getSamplePosters(): List<GuidanceMedia> {
    return listOf(
        GuidanceMedia("p1", "Kinematics Formula Chart", "Projectile formulas, variable calculus.", "Poster", "https://unsplash.com"),
        GuidanceMedia("p2", "Periodic Table Trends Map", "Electronegativity, Ionization charts.", "Poster", "https://unsplash.com")
    )
}
