# Keep rules for release build
-dontwarn kotlinx.coroutines.**
