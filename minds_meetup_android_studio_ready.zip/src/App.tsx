import { useState, useEffect, FormEvent } from 'react';
import { 
  Check, 
  X, 
  ChevronRight, 
  ArrowLeft, 
  Timer, 
  BookOpen, 
  Award, 
  History, 
  Smartphone, 
  Laptop, 
  Plus, 
  Search, 
  Video, 
  Image as ImageIcon, 
  Settings, 
  AlertCircle, 
  Trash2, 
  Play, 
  Menu, 
  Sparkles, 
  ShieldAlert, 
  Download, 
  Copy, 
  FileText, 
  Terminal, 
  GraduationCap, 
  TrendingUp, 
  XCircle, 
  AlertTriangle,
  BadgeAlert,
  Save,
  CheckCircle2,
  FileCode2,
  Tv2,
  Share2,
  QrCode
} from 'lucide-react';
import QRCode from 'qrcode';
import { AnimatePresence, motion } from 'motion/react';
import { sampleTests, sampleVideos, samplePosters } from './sampleData';
import { androidProjectSources, AndroidFile } from './androidSources';
import { Test, Question, Attempt } from './types';
import { generateProceduralTests } from './questionGenerator';

const proceduralTestsList = generateProceduralTests();

export default function App() {
  // Global View states: 'simulator' (interactive) | 'split' (simulator + code explorer) | 'code' (code explorer only)
  const [viewMode, setViewMode] = useState<'simulator' | 'split' | 'code'>('split');
  const [isPureAppView, setIsPureAppView] = useState(true);

  // Auto handle viewMode based on pure app viewport view
  useEffect(() => {
    if (isPureAppView) {
      setViewMode('simulator');
    }
  }, [isPureAppView]);
  
  // Simulated Mobile States
  const [isMobilePowerOn, setIsMobilePowerOn] = useState(true);
  const [mobileTime, setMobileTime] = useState('12:00');
  const [simulatorFullScreen, setSimulatorFullScreen] = useState(false);

  // App States inside the simulator
  const [appScreen, setAppScreen] = useState<'splash' | 'home' | 'subject_select' | 'test_list' | 'test_screen' | 'result_screen' | 'solutions' | 'history' | 'guidance' | 'admin'>('home');
  
  // Navigation Parameter memory
  const [selectedCategory, setSelectedCategory] = useState<'Class 10' | 'Class 11' | 'Class 12' | 'JEE' | 'NEET'>('Class 10');
  const [selectedSubject, setSelectedSubject] = useState<string>('Science');
  const [activeTest, setActiveTest] = useState<Test | null>(null);
  const [activeAttempt, setActiveAttempt] = useState<Attempt | null>(null);
  const [testSearchQuery, setTestSearchQuery] = useState('');

  // Active MCQ Test Taker states
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, 'A' | 'B' | 'C' | 'D' | null>>({});
  const [markedForReview, setMarkedForReview] = useState<Record<string, boolean>>({});
  const [timeLeft, setTimeLeft] = useState(600); // Default 10 minutes in seconds
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  // Persistence: Local Storage attempt history
  const [attemptHistory, setAttemptHistory] = useState<Attempt[]>([]);
  
  // Dynamically Admin added tests in memory
  const [customTests, setCustomTests] = useState<Test[]>([]);

  // Code Explorer States
  const [selectedSourceFile, setSelectedSourceFile] = useState<AndroidFile>(androidProjectSources[0]);
  const [copiedNotification, setCopiedNotification] = useState(false);

  // Admin Form parameters
  const [newTestTitle, setNewTestTitle] = useState('');
  const [newTestCategory, setNewTestCategory] = useState<'Class 10' | 'Class 11' | 'Class 12' | 'JEE' | 'NEET'>('Class 10');
  const [newTestSubject, setNewTestSubject] = useState('Science');
  const [newTestChapter, setNewTestChapter] = useState('');
  const [newTestDifficulty, setNewTestDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');
  const [newTestDuration, setNewTestDuration] = useState('10');
  const [adminLog, setAdminLog] = useState('');

  // Media Tab state (0 = Videos, 1 = Posters)
  const [mediaTab, setMediaTab] = useState<number>(0);

  // Elegant in-app custom modal states (prevents iframe confirm/alert blocker bugs)
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [showClearHistoryModal, setShowClearHistoryModal] = useState(false);
  const [appAlertDialog, setAppAlertDialog] = useState<string | null>(null);
  const [activeVideo, setActiveVideo] = useState<any | null>(null);

  // High-fidelity Share/Promote QR state and generator
  const [showQRCodeModal, setShowQRCodeModal] = useState(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);

  const handleOpenShareQR = async () => {
    const appUrl = window.location.origin + window.location.pathname;
    try {
      const dataUrl = await QRCode.toDataURL(appUrl, {
        margin: 2,
        scale: 8,
        width: 320,
        color: {
          dark: '#1e1b4b',
          light: '#ffffff'
        }
      });
      setQrCodeDataUrl(dataUrl);
      setShowQRCodeModal(true);
    } catch (err) {
      console.error(err);
      setQrCodeDataUrl(`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(appUrl)}`);
      setShowQRCodeModal(true);
    }
  };

  const handleCopyLink = () => {
    const appUrl = window.location.origin + window.location.pathname;
    navigator.clipboard.writeText(appUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Synchronize appScreen & modal overlay visibility with browser history.
  // This captures physical phone back buttons, forward navigations, and swipe/hardware gestures natively!
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      // 1. If any overlay is active, close it first to act as a physical "dismiss / close / minimize"
      if (showQRCodeModal) {
        setShowQRCodeModal(false);
        window.history.pushState({ screen: appScreen }, '');
        return;
      }
      if (activeVideo) {
        setActiveVideo(null);
        window.history.pushState({ screen: appScreen }, '');
        return;
      }
      if (showSubmitModal) {
        setShowSubmitModal(false);
        window.history.pushState({ screen: appScreen }, '');
        return;
      }
      if (showClearHistoryModal) {
        setShowClearHistoryModal(false);
        window.history.pushState({ screen: appScreen }, '');
        return;
      }
      if (appAlertDialog) {
        setAppAlertDialog(null);
        window.history.pushState({ screen: appScreen }, '');
        return;
      }

      // 2. Otherwise update active app routing screen to the popstate history value
      if (event.state && event.state.screen) {
        setAppScreen(event.state.screen);
      } else {
        setAppScreen('home');
      }
    };

    window.addEventListener('popstate', handlePopState);

    // Initial state setup on device mount
    if (!window.history.state) {
      window.history.replaceState({ screen: appScreen }, '');
    }

    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [showQRCodeModal, activeVideo, showSubmitModal, showClearHistoryModal, appAlertDialog, appScreen]);

  // Synchronize dynamic screen state updates into history stack
  useEffect(() => {
    if (window.history.state && window.history.state.screen !== appScreen) {
      if (appScreen === 'splash' || appScreen === 'home') {
        window.history.replaceState({ screen: appScreen }, '');
      } else {
        window.history.pushState({ screen: appScreen }, '');
      }
    }
  }, [appScreen]);

  // Update simulator mock clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12 || 12; // 12 hour format
      setMobileTime(`${hours}:${minutes} ${ampm}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Retrieve attempt histories from localStorage on init
  useEffect(() => {
    try {
      const saved = localStorage.getItem('minds_meetup_history');
      if (saved) {
        setAttemptHistory(JSON.parse(saved));
      }
    } catch (e) {
      console.error("Error reading storage", e);
    }
  }, []);

  // Save attempts to storage when changed
  const saveAttemptToStorage = (newHistory: Attempt[]) => {
    try {
      localStorage.setItem('minds_meetup_history', JSON.stringify(newHistory));
      setAttemptHistory(newHistory);
    } catch (e) {
      console.error("Error writing storage", e);
    }
  };

  // Clear all past records helper
  const clearPastHistory = () => {
    setShowClearHistoryModal(true);
  };

  const confirmActionClearHistory = () => {
    saveAttemptToStorage([]);
    setShowClearHistoryModal(false);
  };

  // Automatically transition splash screen after 0.1 seconds (100ms) for high-speed instant load
  useEffect(() => {
    if (appScreen === 'splash') {
      const timer = setTimeout(() => {
        setAppScreen('home');
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [appScreen]);

  // Handle count down timer inside mock exams
  useEffect(() => {
    let timerId: NodeJS.Timeout;
    if (appScreen === 'test_screen' && isTimerRunning && timeLeft > 0) {
      timerId = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && appScreen === 'test_screen') {
      // Auto submit test when timer runs dry
      submitCurrentTest(true);
    }
    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [appScreen, isTimerRunning, timeLeft]);

  // Combine static, custom admin, and procedural tests to meet the target of 500+ questions per subject
  const combinedTestsList = [...sampleTests, ...customTests, ...proceduralTestsList];

  // Helper translations representing actual subjects for each stream
  const categorySubjects: Record<string, string[]> = {
    'Class 10': ['Science', 'Maths', 'Social Science', 'English', 'Hindi'],
    'Class 11': ['Physics', 'Chemistry', 'Maths', 'Biology'],
    'Class 12': ['Physics', 'Chemistry', 'Maths', 'Biology'],
    'JEE': ['Physics', 'Chemistry', 'Maths'],
    'NEET': ['Physics', 'Chemistry', 'Biology']
  };

  const getSubjectIconEmoji = (subject: string): string => {
    const maps: Record<string, string> = {
      'Science': '🔬',
      'Maths': '📐',
      'Social Science': '🌍',
      'English': '📖',
      'Hindi': '✍️',
      'Physics': '⚛️',
      'Chemistry': '🧪',
      'Biology': '🧬'
    };
    return maps[subject] || '📚';
  };

  const getSubjectColorStyles = (subject: string) => {
    const maps: Record<string, { bg: string; text: string; border: string; ring: string; hoverGlow: string }> = {
      'Science': { 
        bg: 'bg-emerald-50/70', 
        text: 'text-emerald-700', 
        border: 'border-emerald-100/80', 
        ring: 'group-hover:ring-emerald-200/50', 
        hoverGlow: 'hover:shadow-emerald-500/10 hover:border-emerald-400 hover:bg-emerald-50/35' 
      },
      'Maths': { 
        bg: 'bg-violet-50/70', 
        text: 'text-violet-700', 
        border: 'border-violet-100/80', 
        ring: 'group-hover:ring-violet-200/50', 
        hoverGlow: 'hover:shadow-violet-500/10 hover:border-violet-400 hover:bg-violet-50/35' 
      },
      'Social Science': { 
        bg: 'bg-sky-50/70', 
        text: 'text-sky-700', 
        border: 'border-sky-100/80', 
        ring: 'group-hover:ring-sky-200/50', 
        hoverGlow: 'hover:shadow-sky-500/10 hover:border-sky-400 hover:bg-sky-50/35' 
      },
      'English': { 
        bg: 'bg-amber-50/70', 
        text: 'text-amber-700', 
        border: 'border-amber-100/80', 
        ring: 'group-hover:ring-amber-200/50', 
        hoverGlow: 'hover:shadow-amber-500/10 hover:border-amber-400 hover:bg-amber-50/35' 
      },
      'Hindi': { 
        bg: 'bg-rose-50/70', 
        text: 'text-rose-700', 
        border: 'border-rose-100/80', 
        ring: 'group-hover:ring-rose-200/50', 
        hoverGlow: 'hover:shadow-rose-500/10 hover:border-rose-400 hover:bg-rose-50/35' 
      },
      'Physics': { 
        bg: 'bg-cyan-50/70', 
        text: 'text-cyan-700', 
        border: 'border-cyan-100/80', 
        ring: 'group-hover:ring-cyan-200/50', 
        hoverGlow: 'hover:shadow-cyan-500/10 hover:border-cyan-400 hover:bg-cyan-50/35' 
      },
      'Chemistry': { 
        bg: 'bg-fuchsia-50/70', 
        text: 'text-fuchsia-700', 
        border: 'border-fuchsia-100/80', 
        ring: 'group-hover:ring-fuchsia-200/50', 
        hoverGlow: 'hover:shadow-fuchsia-500/10 hover:border-fuchsia-400 hover:bg-fuchsia-50/35' 
      },
      'Biology': { 
        bg: 'bg-teal-50/70', 
        text: 'text-teal-700', 
        border: 'border-teal-100/80', 
        ring: 'group-hover:ring-teal-200/50', 
        hoverGlow: 'hover:shadow-teal-500/10 hover:border-teal-400 hover:bg-teal-50/35' 
      },
    };
    return maps[subject] || { 
      bg: 'bg-blue-50/70', 
      text: 'text-blue-700', 
      border: 'border-blue-100/80', 
      ring: 'group-hover:ring-blue-200/50', 
      hoverGlow: 'hover:shadow-blue-500/10 hover:border-blue-400 hover:bg-blue-50/35' 
    };
  };

  const getHinglishSubjectTitle = (subject: string): string => {
    return subject;
  };

  // Launch a new test
  const startTest = (test: Test) => {
    setActiveTest(test);
    setCurrentQuestionIndex(0);
    // Initialize answers object with nulls
    const initAnswers: Record<string, 'A' | 'B' | 'C' | 'D' | null> = {};
    const initReview: Record<string, boolean> = {};
    test.questions.forEach(q => {
      initAnswers[q.id] = null;
      initReview[q.id] = false;
    });
    setSelectedOptions(initAnswers);
    setMarkedForReview(initReview);
    setTimeLeft(test.durationMinutes * 60);
    setIsTimerRunning(true);
    setAppScreen('test_screen');
  };

  // Submit test calculations
  const submitCurrentTest = (wasTimeout = false, forceNoConfirm = false) => {
    if (!activeTest) return;

    if (!wasTimeout && !forceNoConfirm) {
      // Trigger our sleek custom modal and pause the test timer momentarily
      setIsTimerRunning(false);
      setShowSubmitModal(true);
      return;
    }

    setIsTimerRunning(false);
    setShowSubmitModal(false);

    // Computing scores (+4 for correct, -1 for wrong, 0 for skipped)
    let score = 0;
    let correct = 0;
    let wrong = 0;
    let skipped = 0;

    activeTest.questions.forEach(q => {
      const userAns = selectedOptions[q.id];
      if (userAns === null || userAns === undefined) {
        skipped++;
      } else if (userAns === q.correctAnswer) {
        correct++;
        score += 4;
      } else {
        wrong++;
        score -= 1;
      }
    });

    const percent = Math.max(0, (score / activeTest.totalMarks) * 100);
    const currentDateString = new Date().toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });

    const newAttempt: Attempt = {
      id: "attempt_" + Date.now(),
      testId: activeTest.id,
      testTitle: activeTest.title,
      category: activeTest.category,
      subject: activeTest.subject,
      date: currentDateString,
      score: score,
      maxScore: activeTest.totalMarks,
      percentage: Number(percent.toFixed(1)),
      correctAnswers: correct,
      wrongAnswers: wrong,
      skippedAnswers: skipped,
      totalQuestions: activeTest.questions.size || activeTest.questions.length,
      selectedAnswers: { ...selectedOptions },
      markedForReview: { ...markedForReview }
    };

    const updatedAttempts = [newAttempt, ...attemptHistory];
    saveAttemptToStorage(updatedAttempts);
    setActiveAttempt(newAttempt);
    setAppScreen('result_screen');
  };

  // Handle strategic quick action: Add custom test dynamically as admin in RAM memory
  const handleCreateMockTest = (e: FormEvent) => {
    e.preventDefault();
    if (!newTestTitle.trim()) {
      setAdminLog("⚠️ Error: Please key in a unique test title.");
      return;
    }
    if (!newTestChapter.trim()) {
      setAdminLog("⚠️ Error: Please declare Chapter context details.");
      return;
    }

    // Capture standard sample question structures (clone the Class 10 Science ones so we have realistic MCQs)
    const baseSampleQuestions = sampleTests[0].questions;

    const dummyNewTest: Test = {
      id: "admin_test_" + Date.now(),
      title: newTestTitle,
      category: newTestCategory,
      subject: newTestSubject,
      chapter: newTestChapter,
      difficulty: newTestDifficulty,
      questionsCount: baseSampleQuestions.length,
      totalMarks: baseSampleQuestions.length * 4,
      durationMinutes: Number(newTestDuration) || 12,
      questions: baseSampleQuestions.map((q, idx) => ({
        ...q,
        id: `custom_q_${idx}_${Date.now()}`
      }))
    };

    setCustomTests(prev => [...prev, dummyNewTest]);
    setAdminLog(`✅ Successfully created test locally in categories: "${newTestCategory} - ${newTestSubject}"!`);
    
    // Clear fields
    setNewTestTitle('');
    setNewTestChapter('');
  };

  // Copy helper
  const copySourceToBuffer = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  const getDifficultyColorClass = (diff: string) => {
    switch (diff) {
      case 'Easy': return 'bg-green-100 text-green-800 border-green-200';
      case 'Medium': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Hard': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  const formatTimerClock = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`min-h-screen text-slate-800 flex flex-col font-sans select-none overflow-x-hidden ${isPureAppView ? 'bg-slate-900 md:bg-slate-950 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.22),rgba(255,255,255,0))]' : 'bg-[#F0F5FA]'}`}>
      
      {/* HEADER SECTION (ELEGANT WHITE CARD BENTO PILL) - HIDDEN IN PURE DIRECT APP VIEW */}
      {!isPureAppView && (
        <header className="bg-white border border-blue-100 px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4 shadow-sm shrink-0 rounded-2xl m-6 mb-2">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/25">
              <GraduationCap className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight text-blue-950 flex items-center gap-2 font-display">
                Mind's Meetup <span className="text-[10px] uppercase px-2.5 py-1 bg-blue-50 text-blue-600 font-bold border border-blue-100 rounded-full select-none">Android Project Workspace</span>
              </h1>
              <p className="text-xs text-slate-500 font-medium">Class 10, 11, 12, JEE & NEET Free Educational Portal Studio</p>
            </div>
          </div>

          {/* WORKSPACE PREVIEW MODE TOGGLERS */}
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200/60 shadow-inner select-none shrink-0">
            <button 
              id="btn-preview-mode"
              onClick={() => { setViewMode('simulator'); setSimulatorFullScreen(false); }}
              className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${viewMode === 'simulator' ? 'bg-white text-blue-600 shadow-sm border border-slate-200/50' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50/50'}`}
            >
              <Smartphone className="h-4 w-4" />
              Simulator Only
            </button>
            
            <button 
              id="btn-split-mode"
              onClick={() => { setViewMode('split'); setSimulatorFullScreen(false); }}
              className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${viewMode === 'split' ? 'bg-white text-blue-600 shadow-sm border border-slate-200/50' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50/50'}`}
            >
              <Laptop className="h-4 w-4" />
              Split Workspace
            </button>

            <button 
              id="btn-code-mode"
              onClick={() => { setViewMode('code'); }}
              className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${viewMode === 'code' ? 'bg-white text-blue-600 shadow-sm border border-slate-200/50' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50/50'}`}
            >
              <FileCode2 className="h-4 w-4" />
              Kotlin Source tree
            </button>
          </div>
        </header>
      )}

      {/* WORKSPACE AREA */}
      <main className={`flex-grow flex overflow-hidden min-h-0 ${isPureAppView ? 'p-0 justify-center items-center h-screen' : 'bg-[#F0F5FA] p-6 pt-3 pb-6 gap-6'}`}>
        
        {/* PANEL A: INTERACTIVE PHONE SIMULATOR */}
        <AnimatePresence mode="wait">
          {(viewMode === 'simulator' || viewMode === 'split') && (
            <motion.section 
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className={`flex-1 flex flex-col items-center justify-center transition-all duration-300 ${isPureAppView ? 'p-0 bg-transparent border-0 rounded-none w-full h-full' : simulatorFullScreen ? 'fixed inset-0 z-50 bg-[#F0F5FA] p-6 overflow-y-auto' : 'relative p-6 bg-white border border-blue-50/80 rounded-3xl shadow-sm overflow-y-auto'}`}
            >
              {/* Back out button if full screened in browser */}
              {simulatorFullScreen && (
                <button 
                  onClick={() => setSimulatorFullScreen(false)}
                  className="fixed top-6 right-6 z-50 bg-slate-900 text-white p-3 rounded-full hover:bg-slate-800 transition shadow-lg border border-slate-700 cursor-pointer"
                >
                  <X className="h-6 w-6" />
                </button>
              )}

              {/* Status Header inside workspace panel */}
              {!simulatorFullScreen && !isPureAppView && (
                <div className="w-full max-w-sm mb-3 flex justify-between items-center text-slate-500 px-2 select-none">
                  <span className="text-xs flex items-center gap-1.5 font-bold tracking-tight">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    Interactive Android Simulator
                  </span>
                  
                  <button 
                    onClick={() => setSimulatorFullScreen(!simulatorFullScreen)}
                    className="text-[11px] bg-slate-100 text-slate-700 border border-slate-200 px-3 py-1.5 rounded-xl hover:bg-slate-200 transition font-bold cursor-pointer"
                  >
                    {simulatorFullScreen ? "Decrease window scale" : "💻 Expand fullscreen"}
                  </button>
                </div>
              )}

              {/* OUTSIDE SMARTPHONE EMULATOR MOCK FRAME */}
              <div 
                id="android-device-frame" 
                className={isPureAppView 
                  ? "relative w-full max-w-[460px] h-screen md:h-[94vh] md:max-h-[850px] bg-slate-50 md:rounded-[42px] md:shadow-2xl flex flex-col overflow-hidden md:border md:border-slate-800/10 select-text shadow-indigo-600/5 select-text" 
                  : "relative w-[390px] h-[780px] bg-slate-950 p-3.5 rounded-[55px] border-4 border-slate-800 shadow-2xl flex flex-col shrink-0 outline outline-offset-1 outline-slate-900/40 shadow-blue-200/20"
                }
              >
                
                {/* Selfie Camera Camera Island notch */}
                {!isPureAppView && (
                  <div className="absolute top-6 left-1/2 transform -translate-x-1/2 w-32 h-6 bg-slate-950 rounded-full z-30 flex items-center justify-center shadow-inner gap-2 px-3">
                    <span className="w-2h-3 rounded-full bg-slate-800 border border-slate-700"></span>
                    <div className="w-14 h-1 rounded-full bg-slate-900"></div>
                  </div>
                )}

                {/* Left Side Buttons volume mocks */}
                {!isPureAppView && (
                  <>
                    <div className="absolute -left-1.5 top-28 w-1 h-12 bg-slate-800 rounded-r-md"></div>
                    <div className="absolute -left-1.5 top-44 w-1 h-16 bg-slate-800 rounded-r-md"></div>
                  </>
                )}

                {/* Right Side Power button */}
                {!isPureAppView && (
                  <button 
                    onClick={() => setIsMobilePowerOn(!isMobilePowerOn)}
                    title="Toggle Mobile Screen"
                    className="absolute -right-1.5 top-36 w-1 h-20 bg-slate-700 hover:bg-red-500 rounded-l-md transition cursor-pointer"
                  ></button>
                )}

                {/* MOBILE SCREEN (INNER CHASSIS) */}
                <div className={`relative flex-1 bg-slate-50 overflow-hidden flex flex-col z-10 text-slate-900 select-text ${isPureAppView ? 'rounded-[32px] md:rounded-[36px]' : 'rounded-[42px] border border-slate-950'}`}>
                  
                  {/* If Screen is Screen off */}
                  {!isMobilePowerOn && !isPureAppView ? (
                    <div className="w-full h-full bg-slate-950 flex flex-col items-center justify-center text-slate-500 font-semibold text-center select-none p-6">
                      <Smartphone className="h-10 w-10 text-slate-800 mb-2 animate-bounce" />
                      <p className="text-xs font-bold text-slate-400">Power Off State</p>
                      <button 
                        onClick={() => setIsMobilePowerOn(true)}
                        className="mt-4 px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-[10px] text-slate-300 hover:text-white transition cursor-pointer"
                      >
                        Turn On Side Button
                      </button>
                    </div>
                  ) : (
                    <>
                      {/* HIGH DENSITY STATUS BAR */}
                      {!isPureAppView && (
                        <header className="bg-blue-600 text-white h-9 px-6 flex justify-between items-center text-[11px] font-bold select-none shrink-0 pt-2 z-20">
                          <span className="font-mono">{mobileTime}</span>
                          <div className="flex items-center gap-2 font-mono">
                            <span>5G</span>
                            <span className="tracking-widest">📶</span>
                            <span>🔋 99%</span>
                          </div>
                        </header>
                      )}

                      {/* APPLET MAIN BODY SCREEN ROUTER */}
                      <div className="flex-1 overflow-y-auto flex flex-col relative bg-slate-50">
                        
                        {/* 1. APP SPLASH SCREEN */}
                        {appScreen === 'splash' && (
                          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-indigo-700 to-slate-900 text-white flex flex-col justify-between p-8 z-30 select-none">
                            <div className="h-1/5"></div>
                            
                            <div className="flex flex-col items-center text-center">
                              {/* Splendid Vector brain share icon */}
                              <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center mb-6 border border-white/20 animate-pulse">
                                <Sparkles className="h-10 w-10 text-white" />
                              </div>
                              <h2 className="text-3xl font-extrabold tracking-tight font-display">Mind's Meetup</h2>
                              <p className="text-slate-200 text-xs mt-2.5 max-w-[240px] leading-relaxed">
                                Free Test Series for Class 10, 11, 12, JEE & NEET Students
                              </p>
                            </div>

                            <div className="flex flex-col items-center gap-2">
                              <div className="flex space-x-1.5">
                                <div className="w-2.5 h-2.5 bg-white rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                                <div className="w-2.5 h-2.5 bg-white rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                                <div className="w-2.5 h-2.5 bg-white rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                              </div>
                              <span className="text-[11px] text-slate-300 font-medium tracking-wide">Version 1.1.0 • Standard CBT Certified App</span>
                            </div>
                          </div>
                        )}

                        {/* 2. HOME SCREEN (BEAUTIFUL MULTI-TRANSITION BENTO GRID PORTAL) */}
                        {appScreen === 'home' && (
                          <div className="flex flex-col h-full bg-slate-50/80">
                            {/* App Branding Top bar */}
                            <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-indigo-700 text-white px-5 py-5 pb-7 rounded-b-[32px] shadow-md relative overflow-hidden shrink-0">
                              <div className="absolute top-0 right-0 w-36 h-36 bg-white/10 rounded-full blur-2xl pointer-events-none -mr-8 -mt-8"></div>
                              <div className="absolute -left-10 -bottom-10 w-28 h-28 bg-blue-500/10 rounded-full blur-xl pointer-events-none"></div>
                              <div className="flex justify-between items-center mb-1.5 relative z-10">
                                <span className="text-xl font-black tracking-tight flex items-center gap-1.5 font-display">
                                  <GraduationCap className="h-5.5 w-5.5 text-amber-300 fill-amber-300/30 animate-pulse" />
                                  Mind's Meetup
                                </span>
                                <div className="flex items-center gap-2">
                                  <button 
                                    onClick={handleOpenShareQR}
                                    className="w-8.5 h-8.5 rounded-2xl bg-white/15 hover:bg-white/25 flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-sm border border-white/10"
                                    title="Get Share Scanner / QR Code"
                                  >
                                    <Share2 className="h-4.5 w-4.5 text-amber-300 animate-pulse" />
                                  </button>
                                  <button 
                                    onClick={() => setAppScreen('admin')}
                                    className="w-8.5 h-8.5 rounded-2xl bg-white/15 hover:bg-white/25 flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-sm border border-white/10"
                                    title="Open Admin View"
                                  >
                                    <Settings className="h-4.5 w-4.5 text-white" />
                                  </button>
                                </div>
                              </div>
                              <p className="text-[10px] text-blue-105 font-black tracking-widest uppercase relative z-10 flex items-center gap-1">
                                <Award className="h-3.5 w-3.5 text-amber-300 animate-pulse" /> Free Premium Practice Portal
                              </p>
                            </div>

                            {/* Bento elements wrapper */}
                            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
                              
                              {/* Element 1: Hero / Tagline Bento Card */}
                              <div className="bg-gradient-to-br from-indigo-600 via-indigo-700 to-blue-800 rounded-3xl p-5 text-white relative overflow-hidden flex flex-col justify-center shadow-lg shadow-indigo-500/10 shrink-0">
                                <div className="absolute right-0 bottom-0 w-28 h-28 bg-white/10 rounded-full blur-2xl pointer-events-none pagination-decoration"></div>
                                <h3 className="text-sm font-black leading-tight font-display mb-1 flex items-center gap-1.5">
                                  <GraduationCap className="h-4.5 w-4.5 text-amber-300 fill-amber-300/20 shrink-0 animate-pulse" />
                                  Mind's Educational Suite
                                </h3>
                                <p className="text-[11px] text-indigo-100 opacity-95 leading-relaxed mb-3.5 font-medium">
                                  Improve your exam standing with free chapter-wise mock test papers containing scientific step-by-step explanations written by expert mentors.
                                </p>
                                <div className="flex gap-2 flex-wrap">
                                  <div className="bg-white/15 backdrop-blur-md px-2.5 py-1 rounded-lg text-[9px] font-black tracking-wider uppercase border border-white/5">540+ Mock papers</div>
                                  <div className="bg-emerald-550/90 text-white backdrop-blur-md px-2.5 py-1 rounded-lg text-[9px] font-black tracking-wider uppercase border border-white/10">100% Free</div>
                                </div>
                              </div>

                              {/* Element 2: Stat Diagnostic Card (Score Diagnostic Tracker) */}
                              <div className="bg-white rounded-3xl p-4.5 border border-slate-200/90 flex flex-col justify-between shadow-xs relative overflow-hidden">
                                <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-slate-50 rounded-full pointer-events-none"></div>
                                <div className="flex justify-between items-center relative z-10">
                                  <span className="text-slate-400 text-[9px] uppercase font-black tracking-widest">Exam Diagnostics</span>
                                  <span className="text-emerald-700 font-extrabold text-[9px] px-2 py-0.5 bg-emerald-50 rounded-full border border-emerald-100 select-none flex items-center gap-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-550 animate-pulse"></span> Active History
                                  </span>
                                </div>
                                <div className="mt-3 flex items-center justify-between relative z-10">
                                  <div className="flex items-center gap-3">
                                    <div className="w-11 h-11 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center font-display text-lg font-black text-blue-700">
                                      📊
                                    </div>
                                    <div>
                                      <div className="text-2xl font-black text-slate-800 font-display leading-none">
                                        {attemptHistory.length > 0 ? (
                                          `${Math.round(attemptHistory.reduce((acc, h) => acc + h.percentage, 0) / attemptHistory.length)}%`
                                        ) : (
                                          "84%"
                                        )}
                                      </div>
                                      <p className="text-[10px] text-slate-500 font-black tracking-tight mt-1">Avg Score Accuracy</p>
                                    </div>
                                  </div>
                                  
                                  <button 
                                    onClick={() => setAppScreen('history')}
                                    className="px-3.5 py-2 bg-slate-900 text-white hover:bg-slate-800 rounded-xl font-black text-[10px] tracking-wide cursor-pointer transition-all duration-155 shadow-sm active:scale-95"
                                  >
                                    View Scoreboard
                                  </button>
                                </div>
                              </div>

                              {/* Element 3: Classes Grid Layout (Bento Grid) */}
                              <div className="space-y-3">
                                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 px-1 font-display flex items-center gap-1.5">
                                  <span>Elite Programs / Select Class</span>
                                  <span className="h-px bg-slate-200 flex-1"></span>
                                </h4>
                                <div className="grid grid-cols-2 gap-3">
                                  
                                  {/* Class 10th Card - Royal Blue themed */}
                                  <div 
                                    onClick={() => {
                                      setSelectedCategory('Class 10');
                                      setAppScreen('subject_select');
                                    }}
                                    className="bg-gradient-to-br from-blue-50/80 to-blue-50/20 hover:from-blue-100/60 hover:to-blue-100/20 border border-blue-100/80 hover:border-blue-400 rounded-3xl p-4 flex flex-col items-center justify-center text-center transition-all cursor-pointer shadow-sm hover:shadow active:scale-95 duration-200 group h-32 relative overflow-hidden"
                                  >
                                    <div className="absolute -right-4 -top-4 w-10 h-10 bg-blue-100/20 rounded-full blur-md"></div>
                                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center mb-2 shadow-sm text-2xl group-hover:scale-110 group-hover:rotate-3 transition duration-150 border border-blue-50">🔟</div>
                                    <h3 className="text-xs font-black text-blue-900 font-display">Class 10</h3>
                                    <p className="text-[9px] text-blue-600 font-bold mt-0.5">Secondary Boards</p>
                                  </div>

                                  {/* Class 12th Card - Purple themed */}
                                  <div 
                                    onClick={() => {
                                      setSelectedCategory('Class 12');
                                      setAppScreen('subject_select');
                                    }}
                                    className="bg-gradient-to-br from-purple-50/80 to-purple-50/20 hover:from-purple-100/60 hover:to-purple-100/20 border border-purple-100/80 hover:border-purple-400 rounded-3xl p-4 flex flex-col items-center justify-center text-center transition-all cursor-pointer shadow-sm hover:shadow active:scale-95 duration-200 group h-32 relative overflow-hidden"
                                  >
                                    <div className="absolute -right-4 -top-4 w-10 h-10 bg-purple-100/20 rounded-full blur-md"></div>
                                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center mb-2 shadow-sm text-2xl group-hover:scale-110 group-hover:rotate-3 transition duration-150 border border-purple-50">🏆</div>
                                    <h3 className="text-xs font-black text-purple-900 font-display">Class 12</h3>
                                    <p className="text-[9px] text-purple-600 font-bold mt-0.5">Senior Boards Prep</p>
                                  </div>

                                  {/* JES Competitions - Sky Blue themed */}
                                  <div 
                                    onClick={() => {
                                      setSelectedCategory('JEE');
                                      setAppScreen('subject_select');
                                    }}
                                    className="bg-gradient-to-br from-sky-50/80 to-sky-50/20 hover:from-sky-100/60 hover:to-sky-100/20 border border-sky-100/80 hover:border-sky-400 rounded-3xl p-4 flex flex-col items-center justify-center text-center transition-all cursor-pointer shadow-sm hover:shadow active:scale-95 duration-200 group h-32 relative overflow-hidden"
                                  >
                                    <div className="absolute -right-4 -top-4 w-10 h-10 bg-sky-100/20 rounded-full blur-md"></div>
                                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center mb-2 shadow-sm text-2xl group-hover:scale-110 group-hover:rotate-3 transition duration-150 border border-sky-50">🚀</div>
                                    <h3 className="text-xs font-black text-sky-900 font-display">JEE Prep</h3>
                                    <p className="text-[9px] text-sky-600 font-bold mt-0.5">IIT J.E.E. Engineering</p>
                                  </div>

                                  {/* NEET Competitions - Emerald Medical themed */}
                                  <div 
                                    onClick={() => {
                                      setSelectedCategory('NEET');
                                      setAppScreen('subject_select');
                                    }}
                                    className="bg-gradient-to-br from-emerald-50/80 to-emerald-50/20 hover:from-emerald-100/60 hover:to-emerald-100/20 border border-emerald-100/80 hover:border-emerald-400 rounded-3xl p-4 flex flex-col items-center justify-center text-center transition-all cursor-pointer shadow-sm hover:shadow active:scale-95 duration-200 group h-32 relative overflow-hidden"
                                  >
                                    <div className="absolute -right-4 -top-4 w-10 h-10 bg-emerald-100/20 rounded-full blur-md"></div>
                                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center mb-2 shadow-sm text-2xl group-hover:scale-110 group-hover:rotate-3 transition duration-150 border border-emerald-50">🌱</div>
                                    <h3 className="text-xs font-black text-emerald-900 font-display">NEET</h3>
                                    <p className="text-[9px] text-emerald-600 font-bold mt-0.5">AIIMS Medical Entry</p>
                                  </div>

                                  {/* Class 11 - Spans 2 wide */}
                                  <div 
                                    onClick={() => {
                                      setSelectedCategory('Class 11');
                                      setAppScreen('subject_select');
                                    }}
                                    className="col-span-2 bg-gradient-to-r from-slate-100/80 to-slate-50 hover:from-slate-200/70 hover:to-slate-100 border border-slate-200/70 hover:border-slate-400 rounded-3xl p-3 flex  items-center justify-center gap-3 cursor-pointer transition shadow-xs active:scale-98 duration-100 group"
                                  >
                                    <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center shadow-xs text-xl group-hover:scale-105 transition border border-slate-100">🎓</div>
                                    <div className="text-left">
                                      <h3 className="text-xs font-black text-slate-800 font-display">Class 11 Science Academic</h3>
                                      <p className="text-[9px] text-slate-500 font-bold mt-0.5">Secondary Science Foundation Core Course</p>
                                    </div>
                                    <ChevronRight className="h-4 w-4 text-slate-400 ml-auto group-hover:translate-x-1.5 transition duration-150" />
                                  </div>
                                </div>
                              </div>

                              {/* Element 4: Interactive Video & media hub trigger (Bento Block) */}
                              <div className="bg-gradient-to-br from-white to-blue-50/25 rounded-3xl p-4.5 border border-slate-200/90 flex flex-col justify-between shadow-xs gap-2">
                                <div className="flex justify-between items-center">
                                  <h4 className="text-xs font-extrabold text-slate-800 font-display flex items-center gap-1.5">
                                    <Video className="h-4 w-4 text-blue-650" /> Guidance Lectures & Posters
                                  </h4>
                                  <span className="text-[8px] bg-red-100 text-red-700 px-2.5 py-0.5 font-black rounded-full select-none tracking-wider">REVISION GEMS</span>
                                </div>
                                <p className="text-[10px] text-slate-500 leading-relaxed font-semibold">
                                  Explore curated educational revision mindmaps, time management tricks, formula cheatsheets, and live board lecture pointers.
                                </p>
                                <button
                                  onClick={() => {
                                    setAppScreen('guidance');
                                    setMediaTab(0);
                                  }}
                                  className="w-full text-blue-600 hover:text-blue-800 font-black text-[10px] uppercase tracking-wider py-2.5 bg-blue-50/70 hover:bg-blue-50 border border-blue-105 rounded-2xl transition mt-1.5 text-center cursor-pointer shadow-inner active:scale-98"
                                >
                                  Browse Videos & Posters
                                </button>
                              </div>

                              {/* Founder & Academic Security / Verification Section */}
                              <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 dark:border-indigo-500/25 border border-indigo-100 rounded-3xl p-4 text-white relative overflow-hidden flex flex-col justify-between shadow-md">
                                <div className="absolute right-0 top-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-xl pointer-events-none"></div>
                                <div className="flex justify-between items-center mb-3">
                                  <span className="text-[9px] font-black tracking-widest text-indigo-300 uppercase flex items-center gap-1">
                                    <Award className="h-3 w-3 text-amber-300 animate-pulse" /> Platform Authenticity
                                  </span>
                                  <span className="text-[8px] bg-indigo-900/60 text-indigo-200 px-2 py-0.5 rounded-full border border-indigo-700/50 font-bold">
                                    § Secure Academic Owner
                                  </span>
                                </div>
                                
                                <div className="flex items-start gap-3">
                                  <img 
                                    src="/src/assets/images/mohit_pandey_suit_photo_1781453600492.jpg" 
                                    alt="Mohit Pandey - Founder & Director" 
                                    referrerPolicy="no-referrer"
                                    className="w-14 h-14 rounded-2xl object-cover shrink-0 border-2 border-indigo-400/80 shadow bg-slate-800"
                                  />
                                  <div className="space-y-0.5">
                                    <h4 className="text-xs font-black tracking-wide text-white font-display">
                                      Mohit Pandey
                                    </h4>
                                    <p className="text-[10px] text-amber-300 font-extrabold">
                                      Founder, Director & Chief Architect
                                    </p>
                                    <p className="text-[9px] text-indigo-200 font-bold">
                                      B.Tech • M.Tech • Ph.D Candidate (NIT Background)
                                    </p>
                                  </div>
                                </div>

                                <div className="mt-3 pt-3 border-t border-indigo-900/60 text-left space-y-1.5">
                                  <p className="text-[9.5px] text-indigo-100 font-medium leading-relaxed">
                                    An academic researcher & mentor with multiple published research/science papers in leading high-impact SCI indexed journals.
                                  </p>
                                  <p className="text-[8.5px] text-indigo-300 font-bold bg-indigo-950/45 p-1.5 rounded-lg border border-indigo-900/40 leading-normal flex items-start gap-1">
                                    <CheckCircle2 className="h-3 w-3 text-emerald-400 shrink-0 mt-0.5 animate-pulse" />
                                    <span>
                                      <strong>Ownership Verified:</strong> Authorship protected by intellectual property laws. Legal action will be initiated against any unauthorized republication.
                                    </span>
                                  </p>
                                </div>
                              </div>

                              {/* Little disclaimer credit */}
                              <div className="text-center text-[9px] text-slate-400 font-bold pt-3 border-t border-slate-200/70">
                                Protected by local cryptographic caching • Version 1.1.0
                              </div>
                            </div>
                          </div>
                        )}


                        {/* 3. SUBJECT SELECTION SCREEN */}
                        {appScreen === 'subject_select' && (
                          <div className="flex flex-col h-full bg-slate-50">
                            {/* Inner header */}
                            <div className="bg-blue-600 text-white px-4 py-3 flex items-center gap-2 shrink-0 shadow">
                              <button onClick={() => setAppScreen('home')} className="p-1 rounded-full hover:bg-blue-700">
                                <ArrowLeft className="h-5 w-5 text-white" />
                              </button>
                              <span className="font-bold text-sm tracking-wide">Category: {selectedCategory}</span>
                            </div>

                            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                              <div className="pb-1">
                                <h3 className="text-base font-extrabold text-slate-800">Choose a Subject</h3>
                                <p className="text-xs text-slate-500">Select a subject from the choices below to list available tests.</p>
                              </div>

                              <div className="grid grid-cols-2 gap-3">
                                {categorySubjects[selectedCategory]?.map((sub) => {
                                  const subjectTests = combinedTestsList.filter(t => t.category === selectedCategory && t.subject === sub);
                                  const count = subjectTests.length;
                                  const qCount = subjectTests.reduce((acc, t) => acc + (t.questionsCount || t.questions.length), 0);
                                  const styles = getSubjectColorStyles(sub);
                                  return (
                                    <div 
                                      key={sub}
                                      onClick={() => {
                                        setSelectedSubject(sub);
                                        setAppScreen('test_list');
                                      }}
                                      className={`bg-white border border-slate-200/80 p-4 rounded-3xl cursor-pointer text-center transition-all active:scale-95 duration-200 group relative overflow-hidden ${styles.hoverGlow}`}
                                    >
                                      {/* Beautiful floating soft colored aura */}
                                      <div className={`absolute -right-6 -top-6 w-12 h-12 rounded-full blur-xl opacity-30 ${styles.bg}`}></div>
                                      
                                      {/* Round avatar containing emoji with customized ring */}
                                      <div className={`w-12 h-12 rounded-2xl mx-auto flex items-center justify-center mb-3 border font-bold text-2xl shadow-sm transition-all duration-300 group-hover:scale-110 group-hover:rotate-3 group-hover:shadow-md ring-0 group-hover:ring-4 ${styles.bg} ${styles.text} ${styles.border} ${styles.ring}`}>
                                        {getSubjectIconEmoji(sub)}
                                      </div>
                                      
                                      <h4 className="text-xs font-black text-slate-800 line-clamp-1 group-hover:text-amber-850 transition-colors font-display">{getHinglishSubjectTitle(sub)}</h4>
                                      
                                      <div className="flex flex-col gap-1 mt-2 items-center">
                                        <span className="inline-block text-[9px] text-slate-500 font-bold px-2.5 py-0.5 bg-slate-100 rounded-full select-none">
                                          {count} Mock Tests
                                        </span>
                                        <span className="inline-block text-[9px] text-emerald-750 font-black tracking-wide px-2 py-0.5 bg-emerald-50/80 border border-emerald-100/75 rounded-full select-none">
                                          {qCount}+ Questions
                                        </span>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        )}

                        {/* 4. CHAPTER WISE AND MOCK TEST LIST SCREEN */}
                        {appScreen === 'test_list' && (
                          <div className="flex flex-col h-full bg-slate-50">
                            {/* Inner header */}
                            <div className="bg-blue-600 text-white px-4 py-3 flex items-center justify-between shrink-0 shadow">
                              <div className="flex items-center gap-2">
                                <button onClick={() => setAppScreen('subject_select')} className="p-1 rounded-full hover:bg-blue-700">
                                  <ArrowLeft className="h-5 w-5 text-white" />
                                </button>
                                <span className="font-bold text-xs truncate max-w-[210px]">{selectedCategory}: {selectedSubject}</span>
                              </div>
                            </div>

                            {/* Search and filtering */}
                            <div className="p-3 bg-white border-b border-slate-200 shrink-0">
                              <div className="relative">
                                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                                <input 
                                  value={testSearchQuery}
                                  onChange={(e) => setTestSearchQuery(e.target.value)}
                                  placeholder="Search test names, chapter, etc..."
                                  className="w-full pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium focus:outline-none focus:border-blue-500"
                                />
                              </div>
                            </div>

                            {/* Tests lists */}
                            <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
                              {(() => {
                                const list = combinedTestsList.filter(t => 
                                  t.category === selectedCategory && 
                                  t.subject === selectedSubject &&
                                  (t.title.toLowerCase().includes(testSearchQuery.toLowerCase()) || 
                                   t.chapter.toLowerCase().includes(testSearchQuery.toLowerCase()))
                                );

                                if (list.length === 0) {
                                  return (
                                    <div className="text-center py-10">
                                      <BookOpen className="h-12 w-12 text-slate-200 mx-auto mb-2" />
                                      <p className="text-xs text-slate-500">No active papers match your search criteria yet!</p>
                                      <p className="text-[10px] text-slate-400 mt-1">Check back later or register dynamic custom modules via the Founder Security Bench.</p>
                                    </div>
                                  );
                                }

                                return list.map((test) => (
                                  <div 
                                    key={test.id}
                                    className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col h-auto justify-between"
                                  >
                                    <div className="flex justify-between items-start gap-1">
                                      <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold border ${getDifficultyColorClass(test.difficulty)}`}>
                                        {test.difficulty}
                                      </span>
                                      <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                                        <Timer className="h-3.5 w-3.5 text-slate-400" /> {test.durationMinutes} Min
                                      </span>
                                    </div>

                                    <div className="mt-2.5">
                                      <h4 className="text-xs font-bold text-slate-800 line-clamp-2">{test.title}</h4>
                                      <p className="text-[10px] text-slate-400 mt-1 font-medium truncate">Chapter: {test.chapter}</p>
                                    </div>

                                    <div className="mt-3.5 pt-3.5 border-t border-slate-100 flex items-center justify-between">
                                      <div className="text-[11px] font-semibold text-slate-500">
                                        Q count: <span className="text-slate-800">{test.questionsCount}</span> • Marks: <span className="text-slate-800 font-bold">{test.totalMarks}</span>
                                      </div>
                                      
                                      <button 
                                        onClick={() => startTest(test)}
                                        className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-3 py-1.5 text-xs font-extrabold shadow-sm active:scale-95 transition flex items-center gap-1"
                                      >
                                        Start Test
                                        <Play className="h-3 w-3 fill-current" />
                                      </button>
                                    </div>
                                  </div>
                                ));
                              })()}
                            </div>
                          </div>
                        )}

                        {/* 5. TIMER-BASED MCQ TEST SCREEN */}
                        {appScreen === 'test_screen' && activeTest && (
                          <div className="flex flex-col h-full bg-slate-50 select-none">
                            {/* Exam Top status */}
                            <div className="bg-blue-600 text-white px-4 py-3 pb-3 flex items-center justify-between shrink-0 shadow relative">
                              <div className="flex flex-col">
                                <span className="text-[10px] uppercase font-bold text-blue-105 opacity-80">Active CBT Examination</span>
                                <span className="text-xs font-black truncate max-w-[160px]">{activeTest.title}</span>
                              </div>
                              <div className="flex items-center gap-1.5 px-3 py-1 bg-white/20 rounded-xl font-mono text-xs font-black">
                                <Timer className="h-4 w-4 animate-pulse text-amber-300" />
                                <span>{formatTimerClock(timeLeft)}</span>
                              </div>
                            </div>

                            {/* Thin Completion Progress Line */}
                            {(() => {
                              const answeredCount = activeTest.questions.filter(q => selectedOptions[q.id] !== null).length;
                              const answeredPercent = (answeredCount / activeTest.questions.length) * 100;
                              return (
                                <div className="w-full h-1.5 bg-blue-100 shrink-0">
                                  <div 
                                    className="h-full bg-emerald-500 transition-all duration-300" 
                                    style={{ width: `${answeredPercent}%` }}
                                  ></div>
                                </div>
                              );
                            })()}

                            {/* Current Question and Options */}
                            {(() => {
                              const q: Question = activeTest.questions[currentQuestionIndex];
                              if (!q) return null;

                              const isCurrentMarked = markedForReview[q.id] || false;
                              const userChoice = selectedOptions[q.id];

                              return (
                                <div className="flex-1 flex flex-col min-h-0">
                                  {/* Horizontal MCQ Question Selector Circle/Grid */}
                                  <div className="bg-[#F8FAFC] px-4 py-3 border-b border-slate-200 flex flex-col gap-1.5 shrink-0 select-none">
                                    <div className="flex justify-between items-center text-[10px] text-slate-500 font-extrabold uppercase">
                                      <span>Diagnostic Navigator / Question Paper:</span>
                                      <span className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full font-bold">
                                        Q {currentQuestionIndex + 1} of {activeTest.questions.length}
                                      </span>
                                    </div>
                                    
                                    <div className="flex gap-2 overflow-x-auto pb-1 select-none select-none scrollbar-none pt-1">
                                      {activeTest.questions.map((questionItem, idx) => {
                                        const qId = questionItem.id;
                                        const isCurrentIdx = idx === currentQuestionIndex;
                                        const isMarkedReview = markedForReview[qId];
                                        const isAnswered = selectedOptions[qId] !== null;

                                        let badgeStyle = "bg-white text-slate-650 border-slate-200 hover:bg-slate-50";
                                        
                                        if (isCurrentIdx) {
                                          badgeStyle = "bg-blue-600 text-white border-blue-700 ring-4 ring-blue-100 font-black";
                                        } else if (isMarkedReview && isAnswered) {
                                          badgeStyle = "bg-purple-100 text-purple-700 border-purple-350 font-bold";
                                        } else if (isMarkedReview) {
                                          badgeStyle = "bg-amber-100 text-amber-700 border-amber-350 font-bold";
                                        } else if (isAnswered) {
                                          badgeStyle = "bg-emerald-50 text-emerald-700 border-emerald-200 font-bold";
                                        }

                                        return (
                                          <button
                                            key={qId}
                                            onClick={() => setCurrentQuestionIndex(idx)}
                                            className={`w-7.5 h-7.5 shrink-0 rounded-xl text-xs border flex items-center justify-center transition-all cursor-pointer relative ${badgeStyle}`}
                                          >
                                            {idx + 1}
                                            {isMarkedReview && !isCurrentIdx && (
                                              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-500 rounded-full border border-white"></span>
                                            )}
                                          </button>
                                        );
                                      })}
                                    </div>
                                  </div>

                                  <div className="flex-1 overflow-y-auto p-4 flex flex-col">
                                    {/* Marks weightage and custom action buttons */}
                                    <div className="flex justify-between items-center mb-3 shrink-0">
                                      <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wide">
                                        Standard: +4 Marks | -1 Negative
                                      </span>
                                      
                                      <div className="flex gap-1.5">
                                        {userChoice !== null && (
                                          <button
                                            onClick={() => {
                                              setSelectedOptions(prev => ({
                                                ...prev,
                                                [q.id]: null
                                              }));
                                            }}
                                            className="text-[9px] font-bold text-red-650 bg-red-50 hover:bg-red-100 border border-red-200 px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                                            title="Reset chosen answer"
                                          >
                                            <Trash2 className="h-3 w-3 shrink-0" /> Clear Choice
                                          </button>
                                        )}
                                        
                                        <button 
                                          onClick={() => {
                                            setMarkedForReview(prev => ({
                                              ...prev,
                                              [q.id]: !isCurrentMarked
                                            }));
                                          }}
                                          className={`flex items-center gap-1 text-[9px] font-extrabold px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${isCurrentMarked ? 'bg-amber-100 text-amber-800 border-amber-300' : 'bg-slate-100 text-slate-650 hover:bg-slate-200 border-slate-200'}`}
                                        >
                                          ★ {isCurrentMarked ? "Marked Review" : "Mark Review"}
                                        </button>
                                      </div>
                                    </div>

                                    {/* Q Content statement */}
                                    <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-sm mb-4 shrink-0">
                                      <p className="text-xs text-slate-800 font-extrabold leading-relaxed text-left">
                                        <span className="text-blue-600 font-black mr-1 text-[11px] uppercase font-mono">Q{currentQuestionIndex + 1}.</span> {q.questionText}
                                      </p>
                                    </div>

                                    {/* MCQ Options list */}
                                    <div className="space-y-2.5 mb-6 text-left">
                                      {[
                                        { code: 'A', text: q.optionA },
                                        { code: 'B', text: q.optionB },
                                        { code: 'C', text: q.optionC },
                                        { code: 'D', text: q.optionD }
                                      ].map((opt) => {
                                        const isSelected = userChoice === opt.code;
                                        return (
                                          <div 
                                            key={opt.code}
                                            onClick={() => {
                                              setSelectedOptions(prev => ({
                                                ...prev,
                                                [q.id]: isSelected ? null : (opt.code as any)
                                              }));
                                            }}
                                            className={`border rounded-2xl p-3.5 cursor-pointer transition-all flex items-center gap-3 active:scale-[0.99] select-none ${isSelected ? 'border-indigo-600 bg-gradient-to-r from-blue-50/70 to-indigo-50/50 shadow-xs' : 'border-slate-200 hover:border-slate-350 bg-white'}`}
                                          >
                                            <div className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-[12px] shrink-0 transition-all ${isSelected ? 'bg-gradient-to-br from-blue-600 to-indigo-600 text-white shadow-xs' : 'bg-slate-100 text-slate-500'}`}>
                                              {opt.code}
                                            </div>
                                            <span className={`text-[11.5px] leading-relaxed ${isSelected ? 'text-indigo-950 font-black' : 'text-slate-700 font-bold'}`}>{opt.text}</span>
                                          </div>
                                        );
                                      })}
                                    </div>

                                    {/* Bottom Navigation Buttons */}
                                    <div className="pt-4 border-t border-slate-200 flex justify-between items-center gap-2 mt-auto shrink-0 select-none">
                                      <button 
                                        onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
                                        disabled={currentQuestionIndex === 0}
                                        className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer transition ${currentQuestionIndex === 0 ? 'border-slate-100 text-slate-300 bg-slate-50' : 'border-slate-200 text-slate-700 bg-white hover:bg-slate-50 active:scale-95'}`}
                                      >
                                        <ArrowLeft className="h-3.5 w-3.5" /> Back
                                      </button>

                                      <button 
                                        onClick={() => submitCurrentTest(false, false)}
                                        className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold rounded-xl shadow-sm hover:shadow active:scale-95 transition flex items-center gap-1 cursor-pointer"
                                      >
                                        <Check className="h-3.5 w-3.5" /> Submit Exam
                                      </button>

                                      <button 
                                        onClick={() => {
                                          if (currentQuestionIndex < activeTest.questions.length - 1) {
                                            setCurrentQuestionIndex(prev => prev + 1);
                                          } else {
                                            submitCurrentTest(false, false);
                                          }
                                        }}
                                        className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold rounded-xl shadow-sm hover:shadow active:scale-95 transition flex items-center gap-1 cursor-pointer"
                                      >
                                        {currentQuestionIndex === activeTest.questions.length - 1 ? "Finish" : "Next"} <ChevronRight className="h-4 w-4" />
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              );
                            })()}
                          </div>
                        )}

                        {/* 6. SUBMIT RESULT SCREEN */}
                        {appScreen === 'result_screen' && activeAttempt && (
                          <div className="flex flex-col h-full bg-slate-50">
                            {/* Result Top */}
                            <div className="bg-blue-600 text-white px-5 py-4 pb-5 rounded-b-2xl shadow-md shrink-0 select-none text-center">
                              <Award className="h-10 w-10 text-amber-200 mx-auto mb-1 animate-bounce" />
                              <h3 className="text-lg font-black tracking-wide">Exam Evaluation Report</h3>
                              <p className="text-[10px] text-blue-100">Attempt score report evaluated successfully</p>
                            </div>

                            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                              {/* Big score statement card */}
                              <div className="bg-white border border-slate-200 rounded-2xl p-5 text-center shadow-sm">
                                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">Total Score Earned</span>
                                <div className="text-3xl font-black text-blue-900 mt-2 mb-1">
                                  {activeAttempt.score} / {activeAttempt.maxScore}
                                </div>
                                <span className="text-[12px] bg-blue-50 text-blue-600 px-3 py-1 rounded-full font-bold">
                                  Rating: {activeAttempt.percentage}% Complete
                                </span>

                                <div className="grid grid-cols-3 gap-1.5 mt-5 pt-4 border-t border-slate-100 text-center select-none">
                                  <div className="p-1.5 bg-green-50 rounded-lg">
                                    <span className="text-[9px] text-slate-400 font-semibold block">Correct</span>
                                    <span className="text-sm font-black text-green-700">{activeAttempt.correctAnswers}</span>
                                  </div>
                                  <div className="p-1.5 bg-red-50 rounded-lg">
                                    <span className="text-[9px] text-slate-400 font-semibold block">Wrong</span>
                                    <span className="text-sm font-black text-red-700">{activeAttempt.wrongAnswers}</span>
                                  </div>
                                  <div className="p-1.5 bg-slate-100 rounded-lg">
                                    <span className="text-[9px] text-slate-400 font-semibold block">Skipped</span>
                                    <span className="text-sm font-black text-slate-700">{activeAttempt.skippedAnswers}</span>
                                  </div>
                                </div>
                              </div>

                              {/* Performance criteria helper indicator */}
                              <div className="bg-white border border-slate-200 rounded-xl p-4">
                                <h4 className="text-xs font-bold text-slate-700">Competency assessment</h4>
                                <div className="w-full bg-slate-100 h-2.5 rounded-full mt-2 overflow-hidden shadow-inner flex">
                                  <div 
                                    className={`h-full ${activeAttempt.percentage >= 70 ? 'bg-green-500' : activeAttempt.percentage >= 40 ? 'bg-amber-500' : 'bg-red-500'}`}
                                    style={{ width: `${activeAttempt.percentage}%` }}
                                  ></div>
                                </div>
                                <p className="text-[10px] text-slate-500 mt-2 leading-relaxed font-medium">
                                  {activeAttempt.percentage >= 70 ? "Excellent standing! Highly competent and prepared for exam configurations." : activeAttempt.percentage >= 40 ? "Steady performance. Go through the solution steps to review weak topics." : "Substantial preparation needed. Re-read course chapters and try again."}
                                </p>
                              </div>

                              {/* Direct Question Breakdown analysis scorecard */}
                              <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm text-left">
                                <h4 className="text-xs font-black text-slate-800 tracking-tight mb-2.5 flex items-center gap-1.5 font-display">
                                  <GraduationCap className="h-4 w-4 text-blue-600" /> Scorecard Breakdown & Analysis
                                </h4>
                                <div className="grid grid-cols-5 gap-2 text-center text-[11px] font-bold select-none">
                                  {(() => {
                                    const testRef = combinedTestsList.find(t => t.id === activeAttempt.testId);
                                    if (!testRef) return null;
                                    return testRef.questions.map((q, idx) => {
                                      const uAns = activeAttempt.selectedAnswers[q.id];
                                      const isCorrect = uAns === q.correctAnswer;
                                      
                                      let colorClass = "bg-slate-50 text-slate-400 border-slate-200"; // Skipped / Unvisited
                                      let label = "Skipped";
                                      if (uAns !== null && uAns !== undefined) {
                                        if (isCorrect) {
                                          colorClass = "bg-green-50 text-green-700 border-green-200";
                                          label = "Correct";
                                        } else {
                                          colorClass = "bg-red-50 text-red-650 border-red-200";
                                          label = "Incorrect";
                                        }
                                      }
                                      return (
                                        <div 
                                          key={q.id} 
                                          className={`py-1.5 rounded-xl border text-xs flex flex-col items-center justify-center ${colorClass}`}
                                          title={`Question ${idx + 1}: ${label}`}
                                        >
                                          <span className="text-[9px] opacity-75 font-mono uppercase">Q{idx + 1}</span>
                                          <span className="font-black mt-0.5 text-xs">
                                            {uAns === null ? "—" : isCorrect ? "✓" : "✗"}
                                          </span>
                                        </div>
                                      );
                                    });
                                  })()}
                                </div>
                                <div className="mt-3 flex justify-between items-center text-[9px] text-slate-400 font-bold uppercase tracking-wider select-none">
                                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500"></span> Correct (+4)</span>
                                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500"></span> Wrong (-1)</span>
                                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-slate-300"></span> Skipped (0)</span>
                                </div>
                              </div>

                              {/* User actions */}
                              <div className="space-y-2 pt-2 shrink-0">
                                <button 
                                  onClick={() => setAppScreen('solutions')}
                                  className="w-full py-2.5 bg-blue-600 font-extrabold text-white text-xs rounded-xl shadow hover:bg-blue-700 transition flex items-center justify-center gap-1.5"
                                >
                                  <CheckCircle2 className="h-4 w-4" /> View Detailed Solutions
                                </button>

                                <button 
                                  onClick={() => setAppScreen('home')}
                                  className="w-full py-2 border border-blue-500 text-blue-600 hover:bg-blue-50/50 font-bold text-xs rounded-xl transition"
                                >
                                  Return to Dashboard
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* 7. DETAILED SOLUTION SCREEN */}
                        {appScreen === 'solutions' && activeAttempt && (
                          <div className="flex flex-col h-full bg-slate-50">
                            {/* Solutions Top header */}
                            <div className="bg-blue-600 text-white px-4 py-3 flex items-center justify-between shrink-0 shadow">
                              <div className="flex items-center gap-2">
                                <button onClick={() => setAppScreen('result_screen')} className="p-1 rounded-full hover:bg-blue-700">
                                  <ArrowLeft className="h-5 w-5 text-white" />
                                </button>
                                <span className="font-extrabold text-xs">Explanations & Correct Answers</span>
                              </div>
                            </div>

                            {/* Solution body */}
                            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                              {(() => {
                                const activeTestRef = combinedTestsList.find(t => t.id === activeAttempt.testId);
                                if (!activeTestRef) return <p className="text-center text-xs text-slate-400">Error rendering solution paper.</p>;

                                return activeTestRef.questions.map((q, idx) => {
                                  const userAns = activeAttempt.selectedAnswers[q.id];
                                  const isCorrect = userAns === q.correctAnswer;

                                  return (
                                    <div key={q.id} className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3">
                                      <div className="flex justify-between items-center">
                                        <span className="text-[10px] text-slate-400 font-extrabold uppercase">Question {idx + 1}</span>
                                        <span className={`text-[9px] px-2.5 py-0.5 rounded font-extrabold ${userAns === null ? 'bg-slate-100 text-slate-500' : isCorrect ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                          {userAns === null ? 'Skipped' : isCorrect ? 'Correct +4' : 'Incorrect -1'}
                                        </span>
                                      </div>

                                      <p className="text-xs text-slate-800 font-extrabold leading-relaxed">{q.questionText}</p>

                                      {/* Render options with colored highlights */}
                                      <div className="space-y-1.5 select-none">
                                        {[
                                          { code: 'A', text: q.optionA },
                                          { code: 'B', text: q.optionB },
                                          { code: 'C', text: q.optionC },
                                          { code: 'D', text: q.optionD }
                                        ].map(opt => {
                                          const isCorrectOption = opt.code === q.correctAnswer;
                                          const isUserChoice = opt.code === userAns;
                                          
                                          let optionStyle = 'border-slate-100 bg-slate-50/50';
                                          if (isCorrectOption) {
                                            optionStyle = 'border-green-400 bg-green-50text-green-900 font-bold';
                                          } else if (isUserChoice) {
                                            optionStyle = 'border-red-400 bg-red-50 text-red-900';
                                          }

                                          return (
                                            <div key={opt.code} className={`border rounded-lg p-2.5 flex items-center gap-2 text-[11px] ${optionStyle}`}>
                                              <div className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] ${isCorrectOption ? 'bg-green-600 text-white' : isUserChoice ? 'bg-red-600 text-white' : 'bg-slate-200 text-slate-700'}`}>
                                                {opt.code}
                                              </div>
                                              <span className="flex-1 font-medium">{opt.text}</span>
                                              {isCorrectOption && <Check className="h-3.5 w-3.5 text-green-600" />}
                                              {isUserChoice && !isCorrectOption && <X className="h-3.5 w-3.5 text-red-600" />}
                                            </div>
                                          );
                                        })}
                                      </div>

                                      {/* Scientific Explanation Block */}
                                      <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 mt-2 select-text">
                                        <div className="text-[10px] font-black text-green-700 uppercase">Correct Option: [{q.correctAnswer}]</div>
                                        <div className="text-[11px] font-bold text-slate-700 mt-1 block">Step-By-Step Solution & Explanation:</div>
                                        <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed font-medium">{q.explanation}</p>
                                      </div>
                                    </div>
                                  );
                                });
                              })()}
                            </div>
                          </div>
                        )}

                        {/* 8. ARCHIVED RESULTS HISTORY SCREEN */}
                        {appScreen === 'history' && (
                          <div className="flex flex-col h-full bg-slate-50">
                            {/* History Header */}
                            <div className="bg-blue-600 text-white px-4 py-3 flex items-center justify-between shrink-0 shadow">
                              <div className="flex items-center gap-2">
                                <button onClick={() => setAppScreen('home')} className="p-1 rounded-full hover:bg-blue-700">
                                  <ArrowLeft className="h-5 w-5 text-white" />
                                </button>
                                <span className="font-extrabold text-sm">Attempt History</span>
                              </div>
                              {attemptHistory.length > 0 && (
                                <button 
                                  onClick={clearPastHistory}
                                  className="text-[10px] bg-red-700 font-extrabold text-white px-2 py-1 rounded hover:bg-red-800 transition"
                                >
                                  Clear
                                </button>
                              )}
                            </div>

                            <div className="flex-1 overflow-y-auto p-4 space-y-3">
                              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Your past attempts</h4>

                              {attemptHistory.length === 0 ? (
                                <div className="text-center py-16 px-4">
                                  <History className="h-12 w-12 text-slate-200 mx-auto mb-2" />
                                  <p className="text-xs text-slate-500 font-bold">No saved attempts found locally!</p>
                                  <p className="text-[10px] text-slate-400 mt-1.5">When you submit a completed CBT paper, detailed scores are stored securely on your device.</p>
                                </div>
                              ) : (
                                attemptHistory.map((item) => (
                                  <div 
                                    key={item.id}
                                    onClick={() => {
                                      setActiveAttempt(item);
                                      setAppScreen('result_screen');
                                    }}
                                    className="bg-white border border-slate-200 hover:border-blue-300 rounded-xl p-3.5 shadow-sm cursor-pointer transition active:scale-98"
                                  >
                                    <div className="flex justify-between items-center text-[9px] text-slate-400 font-extrabold">
                                      <span>{item.category.toUpperCase()} • {item.subject.toUpperCase()}</span>
                                      <span>{item.date}</span>
                                    </div>
                                    <h5 className="text-xs font-bold text-slate-800 tracking-tight mt-1 mb-2 line-clamp-1">{item.testTitle}</h5>
                                    
                                    <div className="flex justify-between items-center pt-2.5 border-t border-slate-100">
                                      <div className="text-[10px] font-semibold text-slate-500">
                                        Score: <span className="text-slate-800 font-black">{item.score}/{item.maxScore}</span>
                                      </div>
                                      <span className="text-xs font-black text-blue-600">{item.percentage}%</span>
                                    </div>
                                  </div>
                                ))
                              )}
                            </div>
                          </div>
                        )}

                        {/* 9. GUIDANCE MEDIA SCREEN (VIDEOS & POSTERS) */}
                        {appScreen === 'guidance' && (
                          <div className="flex flex-col h-full bg-slate-50">
                            {/* Header */}
                            <div className="bg-blue-600 text-white px-4 py-3 flex items-center gap-2 shrink-0 shadow">
                              <button onClick={() => setAppScreen('home')} className="p-1 rounded-full hover:bg-blue-700">
                                <ArrowLeft className="h-5 w-5 text-white" />
                              </button>
                              <span className="font-extrabold text-sm">Videos & Revision Hub</span>
                            </div>

                            {/* Selection tab bars */}
                            <div className="flex border-b border-slate-200 bg-white shadow-sm shrink-0 select-none">
                              <button 
                                onClick={() => setMediaTab(0)}
                                className={`flex-1 py-2.5 text-xs font-extrabold ${mediaTab === 0 ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400'}`}
                              >
                                Video Lectures
                              </button>
                              
                              <button 
                                onClick={() => setMediaTab(1)}
                                className={`flex-1 py-2.5 text-xs font-extrabold ${mediaTab === 1 ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400'}`}
                              >
                                Revision Charts & Posters
                              </button>
                            </div>

                            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                              {mediaTab === 0 ? (
                                <div className="space-y-4">
                                  {sampleVideos.map((vid) => (
                                    <div 
                                      key={vid.id} 
                                      onClick={() => setActiveVideo(vid)}
                                      className="bg-white border border-slate-200 hover:border-blue-400 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer group"
                                    >
                                      <div className="relative h-28 bg-slate-900 overflow-hidden flex items-center justify-center">
                                        <img src={vid.thumbnailUrl} alt={vid.title} className="absolute inset-0 w-full h-full object-cover opacity-75 group-hover:scale-105 transition-transform duration-300" />
                                        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/35 transition-colors"></div>
                                        <div className="absolute w-11 h-11 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg transition-transform duration-200 group-hover:scale-110 z-10">
                                          <Play className="h-4 w-4 text-white fill-current translate-x-0.5" />
                                        </div>
                                        {vid.id.startsWith('promo-') && (
                                          <span className="absolute top-2 left-2 bg-rose-600/90 backdrop-blur-sm text-white text-[8px] font-black tracking-widest uppercase px-2 py-0.5 rounded-full shadow-sm">
                                            PROMO Video
                                          </span>
                                        )}
                                      </div>
                                      <div className="p-3.5 text-left font-sans">
                                        <h5 className="text-[11.5px] font-black text-slate-800 group-hover:text-blue-600 transition-colors line-clamp-1">{vid.title}</h5>
                                        <p className="text-[9.5px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">{vid.description}</p>
                                        <button 
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setActiveVideo(vid);
                                          }}
                                          className="w-full mt-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-600 text-[10px] font-black tracking-wide uppercase rounded-xl transition-colors flex items-center justify-center gap-1.5 border border-blue-100"
                                        >
                                          <Play className="h-2.5 w-2.5 fill-current" /> Play Video Lecture
                                        </button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                <div className="grid grid-cols-2 gap-3 pb-4 select-none">
                                  {samplePosters.map((post) => (
                                    <div key={post.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col justify-between text-left">
                                      <div className="h-20 bg-blue-50 overflow-hidden relative">
                                        <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover opacity-80" />
                                      </div>
                                      <div className="p-2.5">
                                        <h5 className="text-[10px] font-bold text-slate-800 line-clamp-1">{post.title}</h5>
                                        <p className="text-[9px] text-slate-400 mt-0.5 line-clamp-2 leading-relaxed">{post.description}</p>
                                        <button 
                                          onClick={() => setAppAlertDialog(`HD Visual Mind Map Ready! Zooming "${post.title}" 🔎`)}
                                          className="w-full mt-2.5 py-1 text-slate-700 hover:text-blue-600 bg-slate-50 text-[10px] font-extrabold rounded"
                                        >
                                          Zoom Poster
                                        </button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                              {/* 10. ADMIN PANEL PLACEHOLDER (SYNC CONTROLLER PREVIEW) */}
                        {appScreen === 'admin' && (
                          <div className="flex flex-col h-full bg-slate-50">
                            {/* Admin Header */}
                            <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white px-4 py-3 pb-4 rounded-b-[24px] shadow-md relative overflow-hidden shrink-0">
                              <div className="absolute right-0 top-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-xl pointer-events-none"></div>
                              <div className="flex items-center gap-2 relative z-10">
                                <button onClick={() => setAppScreen('home')} className="p-1.5 rounded-xl hover:bg-white/10 active:scale-95 transition">
                                  <ArrowLeft className="h-5 w-5 text-indigo-200" />
                                </button>
                                <div>
                                  <span className="block font-black text-xs text-indigo-300 uppercase tracking-widest leading-none">Security Console</span>
                                  <span className="font-extrabold text-sm text-white">Owner & IP Verification</span>
                                </div>
                              </div>
                            </div>
 
                            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                              {/* Founder Identity Card */}
                              <div className="bg-gradient-to-br from-white to-slate-50 border border-slate-200/90 rounded-3xl p-4.5 shadow-sm space-y-3.5">
                                <div className="flex justify-between items-center pb-2.5 border-b border-slate-100">
                                  <span className="text-[9px] font-black tracking-widest text-emerald-600 uppercase flex items-center gap-1">
                                    <CheckCircle2 className="h-4 w-4 text-emerald-500 fill-emerald-500/10" /> Registered Creator
                                  </span>
                                  <span className="text-[8px] bg-indigo-50 text-indigo-700 border border-indigo-100 px-2.5 py-0.5 rounded-full font-extrabold">
                                    NIT Alumnus
                                  </span>
                                </div>

                                <div className="flex gap-3.5 items-start">
                                  <img 
                                    src="/src/assets/images/mohit_pandey_suit_photo_1781453600492.jpg"
                                    alt="Mohit Pandey - Executive Officer"
                                    referrerPolicy="no-referrer"
                                    className="w-16 h-16 rounded-2xl object-cover border-2 border-indigo-500/20 shadow-md shrink-0 focus-ring"
                                  />
                                  <div className="space-y-1">
                                    <h4 className="text-sm font-black text-slate-800 font-display">
                                      Mohit Pandey
                                    </h4>
                                    <p className="text-[10px] text-indigo-650 font-extrabold leading-none">
                                      Chief Founder & Director
                                    </p>
                                    <p className="text-[9px] text-slate-500 font-bold leading-normal">
                                      B.Tech • M.Tech • Ph.D Candidate <br />
                                      <span className="text-amber-800">Specialization: Scientific Computing & Engineering Solutions</span>
                                    </p>
                                  </div>
                                </div>

                                {/* Scientific Publications List */}
                                <div className="bg-indigo-50/20 border border-indigo-100/60 rounded-2xl p-3 text-left">
                                  <h5 className="text-[9px] font-black text-indigo-900 uppercase tracking-widest mb-1.5 flex items-center gap-1">
                                    <Award className="h-3 w-3 text-amber-500" /> Research & Science Papers
                                  </h5>
                                  <p className="text-[9.5px] text-slate-600 font-medium leading-relaxed">
                                    Multiple peer-reviewed scientific papers published in high-impact leading international journals indexed in <strong>SCI (Science Citation Index)</strong>, Web of Science, and Scopus.
                                  </p>
                                </div>

                                {/* Legal IPR Notice to secure app publishing */}
                                <div className="bg-red-50/30 border border-red-100 rounded-2xl p-3 text-left space-y-1">
                                  <h5 className="text-[9px] font-black text-red-700 uppercase tracking-widest flex items-center gap-1 select-none">
                                    <ShieldAlert className="h-3.5 w-3.5 text-red-500" /> Exclusive Legal Ownership (IPR Safeguard)
                                  </h5>
                                  <p className="text-[9px] text-slate-600 font-semibold leading-relaxed">
                                    All core logic modules, testing methodologies, answers, step-by-step solutions, and materials are legally protected by Intellectual Property Rights (IPR). Legal actions will be taken against anyone attempting to download, copy, republish, or sell this platform without direct consent from <strong>Mohit Pandey</strong>.
                                  </p>
                                </div>
                              </div>

                              {/* Sync Warning */}
                              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3.5 flex items-start gap-2.5">
                                <ShieldAlert className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                                <div>
                                  <h4 className="text-xs font-bold text-amber-900">Verified System Bench</h4>
                                  <p className="text-[10px] text-amber-700 leading-relaxed mt-0.5">
                                    This private security dashboard confirms administrative validation status. Local memory updates are protected.
                                  </p>
                                </div>
                              </div>

                              {/* Form element to simulate add dynamic tests */}
                              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                                <h4 className="text-xs font-extrabold text-slate-800 flex items-center gap-1">
                                  <Plus className="h-4 w-4 text-blue-600" /> Add New Test Core
                                </h4>
                                
                                <form onSubmit={handleCreateMockTest} className="space-y-3 mt-3.5">
                                  <div>
                                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Test Title</label>
                                    <input 
                                      value={newTestTitle}
                                      onChange={(e) => setNewTestTitle(e.target.value)}
                                      placeholder="e.g., Board Prep Unit 1, Rotational motion, etc."
                                      className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:outline-none focus:border-blue-500"
                                    />
                                  </div>

                                  <div className="grid grid-cols-2 gap-2.5">
                                    <div>
                                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Category / Class</label>
                                      <select 
                                        value={newTestCategory}
                                        onChange={(e) => {
                                          const cat = e.target.value as any;
                                          setNewTestCategory(cat);
                                          // Set default subject compatible with category
                                          setNewTestSubject(categorySubjects[cat][0]);
                                        }}
                                        className="w-full px-2.5 py-1.5 border border-slate-200 bg-white rounded-lg text-xs font-semibold focus:outline-none"
                                      >
                                        <option value="Class 10">Class 10</option>
                                        <option value="Class 11">Class 11</option>
                                        <option value="Class 12">Class 12</option>
                                        <option value="JEE">JEE</option>
                                        <option value="NEET">NEET</option>
                                      </select>
                                    </div>

                                    <div>
                                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Subject</label>
                                      <select 
                                        value={newTestSubject}
                                        onChange={(e) => setNewTestSubject(e.target.value)}
                                        className="w-full px-2.5 py-1.5 border border-slate-200 bg-white rounded-lg text-xs font-semibold focus:outline-none focus:border-blue-500"
                                      >
                                        {categorySubjects[newTestCategory]?.map(sub => (
                                          <option key={sub} value={sub}>{sub}</option>
                                        ))}
                                      </select>
                                    </div>
                                  </div>

                                  <div className="grid grid-cols-2 gap-2.5">
                                    <div>
                                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Chapter/Unit Context</label>
                                      <input 
                                        value={newTestChapter}
                                        onChange={(e) => setNewTestChapter(e.target.value)}
                                        placeholder="e.g., Chapter 4: Light"
                                        className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:outline-none focus:border-blue-500"
                                      />
                                    </div>

                                    <div>
                                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Duration (Min)</label>
                                      <input 
                                        type="number"
                                        value={newTestDuration}
                                        onChange={(e) => setNewTestDuration(e.target.value)}
                                        placeholder="12"
                                        className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:outline-none focus:border-blue-500"
                                      />
                                    </div>
                                  </div>

                                  <button
                                    type="submit"
                                    className="w-full mt-2 py-2 bg-slate-800 hover:bg-slate-900 border border-slate-700 text-white text-xs font-black rounded-lg transition"
                                  >
                                    Publish & Add Test (Instantly Live)
                                  </button>
                                </form>
                              </div>

                              {/* Operations placeholders trigger */}
                              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm select-none">
                                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3.5">Database & Production Sync Control</h4>
                                <div className="space-y-2">
                                  {[
                                    "Add Question",
                                    "Upload CSV File",
                                    "Add Revision Poster",
                                    "Add Guidance Video",
                                    "Manage Active Tests"
                                  ].map((act) => (
                                    <div 
                                      key={act}
                                      onClick={() => setAdminLog(`Click registered on: "${act}". Ready for Firebase.`)}
                                      className="p-2.5 border border-slate-100 hover:border-slate-300 rounded-lg flex items-center justify-between text-[11px] font-semibold text-slate-700 cursor-pointer transition active:bg-slate-50"
                                    >
                                      <span>{act}</span>
                                      <ChevronRight className="h-4 w-4 text-slate-400" />
                                    </div>
                                  ))}
                                </div>
                              </div>

                              {/* Feed logs */}
                              {adminLog && (
                                <div className="p-3 bg-slate-100 border border-slate-200 rounded-xl text-[10px] text-slate-700 font-mono flex items-start gap-1.5 select-text leading-relaxed">
                                  <Terminal className="h-4 w-4 text-blue-600 shrink-0 mt-0.5" />
                                  <span>{adminLog}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        )}

                        {/* Virtual Custom Modal Overlay 1: Exam Submission Confirm */}
                        {showSubmitModal && activeTest && (
                          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-40 select-none animate-in fade-in duration-200">
                            <div className="bg-white rounded-3xl p-5 w-full max-w-[280px] text-center shadow-2xl border border-slate-100 flex flex-col gap-3 scale-95 duration-100 animate-in zoom-in-95">
                              <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto shadow-sm">
                                <Award className="h-6 w-6" />
                              </div>
                              <div>
                                <h3 className="text-sm font-black text-slate-850">Submit Exam papers?</h3>
                                <p className="text-[10px] text-slate-400 font-bold uppercase mt-0.5">Evaluate Exam Results</p>
                              </div>

                              <p className="text-[10.5px] text-slate-500 leading-normal font-medium max-w-[240px] mx-auto">
                                Are you ready to submit your exam answers for official score evaluation?
                              </p>

                              {/* Live MCQ summary stats inside the modal */}
                              <div className="grid grid-cols-2 gap-1.5 p-2 bg-slate-50 rounded-2xl text-[10px] text-slate-500 font-bold my-1 text-left">
                                <div className="border-r border-slate-200 px-1">
                                  <span className="block text-slate-400 uppercase text-[8px]">Answered</span>
                                  <span className="text-emerald-700 font-black text-xs">
                                    {activeTest.questions.filter(q => selectedOptions[q.id] !== null).length} questions
                                  </span>
                                </div>
                                <div className="px-1 pl-2">
                                  <span className="block text-slate-400 uppercase text-[8px]">Blank/Left</span>
                                  <span className="text-slate-700 font-black text-xs">
                                    {activeTest.questions.filter(q => selectedOptions[q.id] === null).length} questions
                                  </span>
                                </div>
                              </div>

                              <div className="space-y-1.5">
                                <button
                                  onClick={() => {
                                    // Submit directly bypassing native confirms
                                    submitCurrentTest(false, true);
                                  }}
                                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-xl transition cursor-pointer shadow-md shadow-blue-500/10 active:scale-95"
                                >
                                  Yes, Diagnose Score
                                </button>
                                <button
                                  onClick={() => {
                                    setIsTimerRunning(true);
                                    setShowSubmitModal(false);
                                  }}
                                  className="w-full py-2 border border-slate-250 hover:bg-slate-50 text-slate-600 font-semibold text-xs rounded-xl transition cursor-pointer"
                                >
                                  Resume Exam
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Virtual Custom Modal Overlay 2: Clear Past History Confirm */}
                        {showClearHistoryModal && (
                          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-40 select-none animate-in fade-in duration-200">
                            <div className="bg-white rounded-3xl p-5 w-full max-w-[280px] text-center shadow-2xl border border-slate-100 flex flex-col gap-3">
                              <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-650 flex items-center justify-center mx-auto">
                                <Trash2 className="h-6 w-6" />
                              </div>
                              <div>
                                <h3 className="text-sm font-black text-slate-850">Clear Past History?</h3>
                                <p className="text-[10px] text-slate-400 font-bold uppercase mt-0.5">Delete scoreboard records</p>
                              </div>

                              <p className="text-[10.5px] text-slate-500 leading-normal font-medium">
                                This will permanently erase your local memory diagnostics. You cannot restore these records.
                              </p>

                              <div className="space-y-1.5 pt-1">
                                <button
                                  onClick={confirmActionClearHistory}
                                  className="w-full py-2 bg-red-650 hover:bg-red-700 text-white font-bold text-xs rounded-xl transition cursor-pointer"
                                >
                                  Yes, Erase All
                                </button>
                                <button
                                  onClick={() => setShowClearHistoryModal(false)}
                                  className="w-full py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 font-semibold text-xs rounded-xl transition cursor-pointer"
                                >
                                  Cancel & Go Back
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Virtual Custom Video Player Modal */}
                        {activeVideo && (
                          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col justify-between z-50 animate-in fade-in duration-200">
                            {/* Player Header */}
                            <div className="bg-slate-900 border-b border-slate-800 text-white px-4 py-3 flex items-center justify-between shrink-0 select-none">
                              <div className="flex flex-col text-left max-w-[80%]">
                                <span className="text-[9px] text-rose-500 font-black tracking-widest uppercase flex items-center gap-1">
                                  <span className="w-1.5 h-1.5 bg-rose-500 rounded-full animate-ping"></span>
                                  {activeVideo.id.startsWith('promo-') ? 'Official App Promo Video' : 'Premium Video Lecture'}
                                </span>
                                <h3 className="text-xs font-black text-slate-100 truncate">{activeVideo.title}</h3>
                              </div>
                              <button 
                                onClick={() => setActiveVideo(null)} 
                                className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center transition cursor-pointer text-slate-300"
                              >
                                <X className="h-4.5 w-4.5" />
                              </button>
                            </div>

                            {/* Simulated High-Fidelity Video Aspect Ratio Monitor box */}
                            <div className="flex-1 flex items-center justify-center p-4 bg-slate-950">
                              <div className="w-full aspect-video rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-2xl relative">
                                <iframe
                                  src={(() => {
                                    try {
                                      const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
                                      const match = activeVideo.videoUrl.match(regExp);
                                      if (match && match[2].length === 11) {
                                        return `https://www.youtube.com/embed/${match[2]}?autoplay=1&mute=0&rel=0&modestbranding=1`;
                                      }
                                      return activeVideo.videoUrl;
                                    } catch (e) {
                                      return activeVideo.videoUrl;
                                    }
                                  })()}
                                  title={activeVideo.title}
                                  className="w-full h-full border-0"
                                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                  allowFullScreen
                                ></iframe>
                              </div>
                            </div>

                            {/* Player Footer Description */}
                            <div className="p-4.5 bg-slate-900 border-t border-slate-800 text-left shrink-0">
                              <p className="text-[10px] text-slate-400 font-bold leading-relaxed">
                                {activeVideo.description}
                              </p>
                              <div className="mt-4 flex items-center justify-between">
                                <span className="text-[9px] text-slate-500 font-extrabold uppercase tracking-wider">Mind's Meetup Stream Engine</span>
                                <button
                                  onClick={() => setActiveVideo(null)}
                                  className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-black text-[10px] rounded-xl uppercase tracking-wider transition-all cursor-pointer shadow-sm shadow-rose-600/30 active:scale-95"
                                >
                                  Close Video
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Custom Share / Promote QR Code Modal */}
                        {showQRCodeModal && (
                          <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-3.5 z-50 overflow-y-auto select-none animate-in fade-in duration-200">
                            <div className="bg-white rounded-[32px] p-5 w-full max-w-[325px] shadow-2xl border border-slate-100 flex flex-col gap-3.5 scale-95 duration-100 animate-in zoom-in-95 max-h-[92%] overflow-y-auto">
                              <div className="flex justify-between items-center -mt-1 select-none">
                                <div className="flex items-center gap-1.5">
                                  <QrCode className="h-5 w-5 text-indigo-600 animate-bounce" />
                                  <h3 className="text-xs font-black text-slate-850 uppercase tracking-widest">Share & Promote</h3>
                                </div>
                                <button 
                                  onClick={() => setShowQRCodeModal(false)}
                                  className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center transition cursor-pointer text-slate-500"
                                >
                                  <X className="h-4 w-4" />
                                </button>
                              </div>

                              {/* Promotional Material Card */}
                              <div id="promo-download-card" className="bg-gradient-to-br from-indigo-50 via-slate-50 to-indigo-100/50 p-4 rounded-3xl border border-indigo-100/80 text-center relative overflow-hidden flex flex-col items-center gap-2.5 shadow-inner">
                                <div className="absolute top-0 right-0 w-16 h-16 bg-indigo-500/5 rounded-full blur-xl pointer-events-none"></div>
                                <h4 className="text-[14px] font-black tracking-tight text-indigo-950 font-display flex items-center gap-1">
                                  <GraduationCap className="h-4 w-4 text-indigo-600 fill-indigo-200" /> Mind's Meetup
                                </h4>
                                <p className="text-[9px] -mt-1 text-indigo-600 font-bold uppercase tracking-wider">Free Practice Portal</p>

                                <div className="bg-white p-2.5 rounded-2xl shadow-md border border-indigo-50 shrink-0">
                                  {qrCodeDataUrl ? (
                                    <img 
                                      src={qrCodeDataUrl} 
                                      alt="App QR Code" 
                                      className="w-36 h-36 border-0 object-contain selection:bg-transparent"
                                      referrerPolicy="no-referrer"
                                    />
                                  ) : (
                                    <div className="w-36 h-36 bg-slate-50 flex items-center justify-center rounded-xl text-slate-400 font-bold text-[10px]">
                                      Generating...
                                    </div>
                                  )}
                                </div>

                                <p className="text-[8.5px] text-slate-500 leading-tight font-black select-none max-w-[200px] mt-1">
                                  📸 SCAN QR TO LAUNCH & PRACTISE FREE!
                                </p>
                              </div>

                              <div className="grid grid-cols-2 gap-2">
                                <button
                                  onClick={handleCopyLink}
                                  className="py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-black text-[10px] rounded-xl transition cursor-pointer flex items-center justify-center gap-1 uppercase tracking-wide cursor-pointer"
                                >
                                  {copiedLink ? (
                                    <>
                                      <Check className="h-3.5 w-3.5 text-emerald-600 font-black animate-pulse" />
                                      Copied!
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="h-3.5 w-3.5 text-slate-600" />
                                      Copy Link
                                    </>
                                  )}
                                </button>

                                <a
                                  href={qrCodeDataUrl}
                                  download="minds_meetup_qr.png"
                                  className="py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-[10px] rounded-xl transition cursor-pointer flex items-center justify-center gap-1 uppercase tracking-wide shadow-md shadow-indigo-600/15 text-center cursor-pointer"
                                >
                                  <Download className="h-3.5 w-3.5" />
                                  Save QR
                                </a>
                              </div>

                              <div className="border-t border-slate-100 pt-3 flex flex-col gap-1.5 text-left">
                                <span className="text-[9.5px] font-black text-slate-700 uppercase tracking-wider">Custom Domain Setup (.com)</span>
                                <div className="text-[9.5px] text-slate-500 leading-relaxed space-y-1.5">
                                  <p>
                                    To use a professional clean .com URL like <strong className="text-indigo-600">mindsmeetup.com</strong> and link it directly to this portal backend:
                                  </p>
                                  <ul className="list-disc pl-4 space-y-1">
                                    <li>Buy domain from <strong>Namecheap</strong>, <strong>Hostinger</strong>, or <strong>GoDaddy</strong>.</li>
                                    <li>Create a <strong>CNAME Record</strong> pointing to Cloud Run/Vercel host routing target.</li>
                                  </ul>
                                  <p className="text-[8.5px] bg-indigo-50/70 p-2 border border-indigo-100/60 rounded-xl text-indigo-950 font-medium">
                                    💡 <strong>Marketing tip:</strong> Print this QR on brochures, school flyers, or pamphlets to drive high traffic of Class 10, 11, 12, JEE & NEET students!
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Virtual Custom Modal Overlay 3: Alert Toast / dialog replacements */}
                        {appAlertDialog && (
                          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-40 select-none animate-in fade-in duration-200">
                            <div className="bg-white rounded-3xl p-5 w-full max-w-[280px] text-center shadow-2xl border border-slate-100 flex flex-col gap-3">
                              <div className="w-11 h-11 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                                <BookOpen className="h-4.5 w-4.5 text-blue-600 animate-pulse" />
                              </div>
                              <h3 className="text-xs font-black text-slate-850 leading-relaxed px-1">
                                {appAlertDialog}
                              </h3>
                              <button
                                onClick={() => setAppAlertDialog(null)}
                                className="w-full mt-1.5 py-2.5 bg-slate-900 hover:bg-slate-850 text-white font-black text-[11px] rounded-xl transition cursor-pointer"
                              >
                                Got it
                              </button>
                            </div>
                          </div>
                        )}

                      </div>

                      {/* PREMIUM IN-APP NATIVE BOTTOM TAB BAR */}
                      {appScreen !== 'splash' && appScreen !== 'test_screen' && appScreen !== 'result_screen' && appScreen !== 'solutions' && (
                        <div className="bg-white border-t border-slate-200/80 h-14 flex justify-around items-center shrink-0 z-20 shadow-[0_-3px_15px_rgba(0,0,0,0.03)] px-2">
                          {/* Tab 1: Practice Portal */}
                          <button 
                            onClick={() => setAppScreen('home')}
                            className={`flex flex-col items-center justify-center flex-1 h-full py-1 text-center transition-all cursor-pointer rounded-xl ${
                              appScreen === 'home' || appScreen === 'subject_select' || appScreen === 'test_list'
                                ? 'text-blue-600 bg-blue-50/30'
                                : 'text-slate-400 hover:text-slate-600'
                            }`}
                          >
                            <BookOpen className={`h-[18px] w-[18px] mb-1 transition-transform ${appScreen === 'home' || appScreen === 'subject_select' || appScreen === 'test_list' ? 'scale-110 font-bold' : ''}`} />
                            <span className="text-[9px] font-black tracking-tight">Practice</span>
                          </button>

                          {/* Tab 2: Guidance Hub */}
                          <button 
                            onClick={() => {
                              setAppScreen('guidance');
                              setMediaTab(0);
                            }}
                            className={`flex flex-col items-center justify-center flex-1 h-full py-1 text-center transition-all cursor-pointer rounded-xl ${
                              appScreen === 'guidance'
                                ? 'text-blue-600 bg-blue-50/30'
                                : 'text-slate-400 hover:text-slate-600'
                            }`}
                          >
                            <Tv2 className={`h-[18px] w-[18px] mb-1 transition-transform ${appScreen === 'guidance' ? 'scale-110 font-bold' : ''}`} />
                            <span className="text-[9px] font-black tracking-tight">Revision Hub</span>
                          </button>

                          {/* Tab 3: History & Scorecard */}
                          <button 
                            onClick={() => setAppScreen('history')}
                            className={`flex flex-col items-center justify-center flex-1 h-full py-1 text-center transition-all cursor-pointer rounded-xl ${
                              appScreen === 'history'
                                ? 'text-blue-600 bg-blue-50/30'
                                : 'text-slate-400 hover:text-slate-600'
                            }`}
                          >
                            <Award className={`h-[18px] w-[18px] mb-1 transition-transform ${appScreen === 'history' ? 'scale-110 font-bold' : ''}`} />
                            <span className="text-[9px] font-black tracking-tight">Scorecard</span>
                          </button>

                          {/* Tab 4: Verify & Admin */}
                          <button 
                            onClick={() => setAppScreen('admin')}
                            className={`flex flex-col items-center justify-center flex-1 h-full py-1 text-center transition-all cursor-pointer rounded-xl ${
                              appScreen === 'admin'
                                ? 'text-emerald-700 bg-emerald-50/40'
                                : 'text-slate-400 hover:text-slate-600'
                            }`}
                          >
                            <CheckCircle2 className={`h-[18px] w-[18px] mb-1 transition-transform ${appScreen === 'admin' ? 'scale-110 text-emerald-600 font-bold' : ''}`} />
                            <span className="text-[9px] font-black tracking-tight">Founder</span>
                          </button>
                        </div>
                      )}

                      {/* PHYSICAL HARDWARE BOTTOM NAVIGATION MOCK */}
                      {!isPureAppView && (
                        <footer className="bg-slate-200 h-12 flex justify-around items-center border-t border-slate-300 relative select-none shrink-0 rounded-b-[42px] px-8">
                          <button 
                            onClick={() => {
                              if (appScreen !== 'home' && appScreen !== 'splash') {
                                // Standard physical hardware backing logic
                                if (appScreen === 'subject_select') setAppScreen('home');
                                else if (appScreen === 'test_list') setAppScreen('subject_select');
                                else if (appScreen === 'test_screen') {
                                  setAppAlertDialog("CBT Exam Protection: Physical Back Key is locked during testing to prevent cheating or loss of data! Please use the 'Back' or 'Submit Exam' buttons provided on the exam card. 📝");
                                }
                                else if (appScreen === 'result_screen') setAppScreen('home');
                                else if (appScreen === 'solutions') setAppScreen('result_screen');
                                else if (appScreen === 'history' || appScreen === 'guidance' || appScreen === 'admin') setAppScreen('home');
                              }
                            }}
                            className="p-1 text-slate-600 hover:text-slate-900 transition-all font-mono text-sm active:scale-90"
                            title="Hardware Back"
                          >
                            ◀
                          </button>
                          
                          <button 
                            onClick={() => {
                              if (appScreen !== 'splash') {
                                setAppScreen('home');
                              }
                            }}
                            className="w-10 h-10 border-2 border-slate-400 hover:border-slate-600 rounded-full active:scale-95 transition"
                            title="Hardware Home"
                          ></button>
                          
                          <button 
                            onClick={() => {
                              setAppAlertDialog("CBT App Lock Rule: Virtual Multitasking switcher is disabled during active test sessions to maintain strict exam integrity. 🔒");
                            }}
                            className="w-4 h-4 border border-slate-600 hover:border-slate-900 rounded-sm active:scale-90 transition"
                            title="Hardware Switcher"
                          ></button>
                        </footer>
                      )}
                    </>
                  )}
                </div>

              </div>
            </motion.section>
          )}
        </AnimatePresence>

        {/* PANEL B: KOTLIN JETPACK COMPOSE SOURCE TREE WORKSPACE */}
        <AnimatePresence mode="wait">
          {(viewMode === 'code' || viewMode === 'split') && (
            <motion.section 
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="flex-1 flex flex-col min-w-0"
            >
              {/* File tree explorer top task bar (Bento header) */}
              <div className="bg-white border border-blue-100 px-5 py-4 flex justify-between items-center shrink-0 rounded-2xl mb-2 ml-2">
                <span className="text-sm font-black text-slate-850 flex items-center gap-1.5 uppercase font-mono tracking-wide">
                  <Terminal className="h-4.5 w-4.5 text-blue-600" />
                  Jetpack Compose Source Explorer
                </span>

                <div className="flex items-center gap-2">
                  <a 
                    href="https://play.google.com/console/signup"
                    target="_blank"
                    rel="noreferrer"
                    className="text-[10px] bg-emerald-50 hover:bg-emerald-100/80 text-emerald-700 px-3 py-1.5 rounded-xl border border-emerald-200 font-extrabold transition flex items-center gap-1 select-none"
                  >
                    <TrendingUp className="h-3.5 w-3.5" />
                    Google Play Ready
                  </a>
                </div>
              </div>

              {/* Grid content */}
              <div className="flex-grow flex min-h-0 bg-transparent gap-4">
                {/* Visual File Sidebar Bento Card */}
                <div className="w-64 bg-white border border-slate-200/80 rounded-2xl flex flex-col shrink-0 select-none overflow-hidden shadow-sm ml-2 py-2">
                  <div className="px-4 py-3 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
                    Kotlin / Android Modules
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-2 space-y-1">
                    {androidProjectSources.map((file) => {
                      const isSelected = file.name === selectedSourceFile.name;
                      return (
                        <div 
                          key={file.name}
                          onClick={() => setSelectedSourceFile(file)}
                          className={`p-2.5 rounded-xl text-xs font-bold cursor-pointer transition flex items-center gap-2 text-ellipsis overflow-hidden border ${isSelected ? 'bg-blue-50 text-blue-700 border-blue-200' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50 border-transparent'}`}
                        >
                          <FileText className={`h-4 w-4 shrink-0 ${isSelected ? 'text-blue-500' : 'text-slate-400'}`} />
                          <div className="text-left font-mono truncate">
                            <span className="block font-black truncate">{file.name}</span>
                            <span className="block text-[8px] text-slate-400 font-medium truncate mt-0.5">{file.path}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="p-3.5 bg-slate-50 border-t border-slate-100 text-[10px] text-slate-500 font-medium leading-relaxed select-text m-2 rounded-xl">
                    💡 These physical files reside in the workspace directory <code className="text-slate-700 text-[9px] font-mono font-bold">/android/</code>. Feel free to export the ZIP to load directly in standard Android Studio!
                  </div>
                </div>

                {/* File Code Code Mirror Presentation Screen */}
                <div className="flex-1 flex flex-col min-w-0 bg-[#0F141F] text-slate-300 font-mono relative rounded-2xl shadow-lg border border-slate-800/80 overflow-hidden">
                  
                  <div className="bg-[#161F30] border-b border-slate-800 px-4 py-3 flex items-center justify-between text-xs font-semibold select-none">
                    <span className="text-[10px] text-slate-400 font-mono tracking-tight font-bold">{selectedSourceFile.path}</span>
                    
                    <button 
                      onClick={() => copySourceToBuffer(selectedSourceFile.content)}
                      className="px-3 py-1.5 bg-[#0F141F] text-slate-300 border border-slate-800 rounded-lg hover:bg-slate-800 hover:text-white transition flex items-center gap-1.5 font-bold cursor-pointer"
                    >
                      {copiedNotification ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-green-400 animate-pulse" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" />
                          Copy Code
                        </>
                      )}
                    </button>
                  </div>

                  {/* Preloaded source editor rendering box */}
                  <div className="flex-1 p-5 overflow-auto text-left block select-text">
                    <pre className="text-xs leading-5 my-0 font-mono tracking-wide overflow-x-auto whitespace-pre">
                      {selectedSourceFile.content}
                    </pre>
                  </div>
                </div>
              </div>
            </motion.section>
          )}
        </AnimatePresence>

      </main>



    </div>
  );
}
