import { Test, Question } from './types';

// Determistically generate high-quality academic questions based on test and question index
function generatePhysicsQuestion(testIdx: number, qIdx: number, category: string): Question {
  const id = `proc_phy_t${testIdx}_q${qIdx}`;
  const d = (testIdx * qIdx) % 100;
  
  // Choose from several real physics question templates
  const templateType = qIdx;
  
  if (templateType === 1) {
    // Ohm's Law / Resistance calculation
    const v = 12 + (testIdx % 10) * 6;
    const r = 2 + (qIdx * 2 + (testIdx % 5));
    const current = (v / r).toFixed(1);
    const correctVal = current + ' A';
    const optA = (v / r * 1.5).toFixed(1) + ' A';
    const optB = correctVal;
    const optC = (v / r * 0.5).toFixed(1) + ' A';
    const optD = (v / r + 2.5).toFixed(1) + ' A';
    
    return {
      id,
      questionText: `An electrical appliance operates with a potential difference of ${v} V. If the heating element has an internal resistance of ${r} Ω, what is the electric current flowing through it? / एक विद्युत उपकरण ${v} V के विभवांतर पर चलता है। यदि इसके तापन तत्व का प्रतिरोध ${r} Ω है, तो प्रवाहित होने वाली विद्युत धारा कितनी है?`,
      optionA: optA,
      optionB: optB,
      optionC: optC,
      optionD: optD,
      correctAnswer: 'B',
      explanation: `According to Ohm's Law (ओम के नियम के अनुसार): I = V / R. Here, V = ${v} V, R = ${r} Ω. Thus, I = ${v} / ${r} = ${current} Amperes (A).`,
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 2) {
    // Kinetic Energy Calculation
    const mass = 10 + (testIdx % 8) * 10;
    const velocity = 2 + (testIdx % 6) * 3;
    const ke = 0.5 * mass * velocity * velocity;
    const correctVal = ke + ' J';
    const optA = ke + ' J';
    const optB = (ke * 2) + ' J';
    const optC = (ke / 2).toFixed(0) + ' J';
    const optD = (ke + 35) + ' J';
    
    return {
      id,
      questionText: `A physical body of mass ${mass} kg is moving with a constant speed of ${velocity} m/s on a frictionless surface. What is the kinetic energy of this body? / ${mass} kg द्रव्यमान का एक भौतिक पिंड घर्षण रहित सतह पर ${velocity} m/s की निरंतर गति से चल रहा है। इस पिंड की गतिज ऊर्जा क्या होगी?`,
      optionA: optA,
      optionB: optB,
      optionC: optC,
      optionD: optD,
      correctAnswer: 'A',
      explanation: `Kinetic Energy (गतिज ऊर्जा) formula: KE = 0.5 * m * v². Given m = ${mass} kg, v = ${velocity} m/s. Hence, KE = 0.5 * ${mass} * (${velocity})² = 0.5 * ${mass} * ${velocity * velocity} = ${ke} Joules (J).`,
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 3) {
    // Focal Length of Mirror
    const r = 20 + (testIdx % 15) * 4;
    const f = r / 2;
    const correctVal = f + ' cm';
    const optA = (f * 2) + ' cm';
    const optB = (f - 5) + ' cm';
    const optC = f + ' cm';
    const optD = (f + 10) + ' cm';
    
    return {
      id,
      questionText: `Find the focal length of a spherical convex mirror whose radius of curvature is ${r} cm. / एक गोलाकार उत्तल दर्पण की फोकस दूरी ज्ञात कीजिए जिसकी वक्रता त्रिज्या ${r} cm है।`,
      optionA: optA,
      optionB: optB,
      optionC: optC,
      optionD: optD,
      correctAnswer: 'C',
      explanation: `For spherical mirrors, the focal length is half of the radius of curvature (गोलीय दर्पणों के लिए, फोकस दूरी वक्रता त्रिज्या की आधी होती है): f = R / 2. Here, R = ${r} cm. So, f = ${r} / 2 = ${f} cm.`,
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 4) {
    // Gravitational Force Ratio or Value
    const forceFactor = (2 + (testIdx % 4) * 2);
    return {
      id,
      questionText: `If the distance between two massive subatomic particles is increased by ${forceFactor} times while keeping their masses constant, the gravitational force between them becomes how many times of original? / यदि दो पिंडों के बीच की दूरी को उनके द्रव्यमान को स्थिर रखते हुए ${forceFactor} गुना बढ़ा दिया जाए, तो उनके बीच गुरुत्वाकर्षण बल मूल बल का कितना गुना हो जाएगा?`,
      optionA: `1 / ${forceFactor}`,
      optionB: `1 / ${forceFactor * forceFactor}`,
      optionC: `${forceFactor}`,
      optionD: `${forceFactor * forceFactor}`,
      correctAnswer: 'B',
      explanation: `According to Newton's Law of Gravitation, F is inversely proportional to square of distance (F ∝ 1 / d²). If distance increases by ${forceFactor} times, force decreases by 1 / (${forceFactor})² = 1 / ${forceFactor * forceFactor} times of the original.`,
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 5) {
    // Capacitor energy
    const capacitance = 2 + (testIdx % 5) * 2; // in microfarads
    const voltage = 10 + (testIdx % 10) * 10;
    const energy = 0.5 * capacitance * 1e-6 * voltage * voltage * 1000; // in millijoules
    const correctVal = energy.toFixed(2) + ' mJ';
    
    return {
      id,
      questionText: `Calculate the energy stored in a capacitor of ${capacitance} μF when charged to a potential difference of ${voltage} V. / ${voltage} V के विभवांतर तक आवेशित करने पर ${capacitance} μF के संधारित्र में संचित ऊर्जा की गणना करें।`,
      optionA: (energy * 2).toFixed(2) + ' mJ',
      optionB: energy.toFixed(2) + ' mJ',
      optionC: (energy / 2).toFixed(2) + ' mJ',
      optionD: (energy + 10).toFixed(2) + ' mJ',
      correctAnswer: 'B',
      explanation: `Energy stored in a capacitor (संधारित्र में संचित ऊर्जा): E = 0.5 * C * V². Here, C = ${capacitance} μF = ${capacitance} × 10⁻⁶ F, V = ${voltage} V. E = 0.5 * (${capacitance} × 10⁻⁶) * (${voltage})² = ${0.5 * capacitance * 1e-6 * voltage * voltage} Joules = ${energy.toFixed(2)} mJ.`,
      difficulty: 'Hard',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 6) {
    // Newton's 2nd Law: Force and acceleration
    const mass = 4 + (testIdx % 10) * 2;
    const force = 12 + (testIdx % 5) * 8;
    const acc = (force / mass).toFixed(2);
    
    return {
      id,
      questionText: `A constant force of ${force} N is applied to a stationary block of mass ${mass} kg. What is the acceleration produced in the block? / ${mass} kg द्रव्यमान के स्थिर ब्लॉक पर ${force} N का निरंतर बल लगाया जाता है। ब्लॉक में उत्पन्न त्वरण कितना होगा?`,
      optionA: acc + ' m/s²',
      optionB: (force * mass) + ' m/s²',
      optionC: (force - mass) + ' m/s²',
      optionD: (force / mass * 0.5).toFixed(2) + ' m/s²',
      correctAnswer: 'A',
      explanation: `According to Newton's Second Law of Motion (न्यूटन के गति के दूसरे नियम से): F = m * a => a = F / m. Here, F = ${force} N, m = ${mass} kg. Acceleration a = ${force} / ${mass} = ${acc} m/s².`,
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 7) {
    // Refractive Index and Speed of light
    const index = (1.2 + (testIdx % 6) * 0.15).toFixed(2);
    const speed = (3.0 / parseFloat(index)).toFixed(2);
    
    return {
      id,
      questionText: `The refractive index of a transparent medium is ${index}. What is the velocity of light inside this medium? (Speed of light in vacuum c = 3.0 × 10⁸ m/s) / एक पारदर्शी माध्यम का अपवर्तनांक ${index} है। इस माध्यम में प्रकाश का वेग कितना होगा?`,
      optionA: `${speed} × 10⁸ m/s`,
      optionB: `3.0 × 10⁸ m/s`,
      optionC: `${(parseFloat(index) * 3).toFixed(1)} × 10⁸ m/s`,
      optionD: `1.50 × 10⁸ m/s`,
      correctAnswer: 'A',
      explanation: `Formula: Refractive Index (n) = Speed of light in vacuum (c) / Speed of light in medium (v). Therefore, v = c / n = 3.0 × 10⁸ / ${index} = ${speed} × 10⁸ m/s.`,
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 8) {
    // Work done calculation
    const f = 20 + (testIdx % 10) * 5;
    const dist = 5 + (testIdx % 4) * 3;
    const angle = 60; // constant 60 degrees (cos 60 = 0.5)
    const work = f * dist * 0.5;
    
    return {
      id,
      questionText: `A constant force of ${f} N pulls a heavy crate through a displacement of ${dist} m. If the force vector is acting at an angle of 60° to the horizontal surface, find the total work done. / ${f} N का एक बल एक बड़े बॉक्स को ${dist} m के विस्थापन से खींचता है। यदि बल क्षतिज के साथ 60° के कोण पर कार्य कर रहा है, तो किया गया कुल कार्य ज्ञात कीजिए।`,
      optionA: (work * 2) + ' Joules',
      optionB: work + ' Joules',
      optionC: (work * 1.732).toFixed(1) + ' Joules',
      optionD: '0 Joules',
      correctAnswer: 'B',
      explanation: `Work Done (कार्य) = F * S * cos(θ). Here, F = ${f} N, S = ${dist} m, θ = 60° (cos 60° = 0.5). Thus, Work = ${f} * ${dist} * 0.5 = ${work} Joules (J).`,
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 9) {
    // Einstein Photoelectric effect concept
    return {
      id,
      questionText: `Which particle model or phenomenon provides the most direct experimental validation for the quantum/particle nature of electromagnetic radiation? / कौन सी घटना विद्युत चुंबकीय विकिरण की क्वांटम/कण प्रकृति के लिए सबसे प्रत्यक्ष प्रयोगात्मक सत्यापन प्रदान करती है?`,
      optionA: 'Young\'s Double Slit Light Interference (व्यतिकरण)',
      optionB: 'Photoelectric Effect (प्रकाश वैद्युत प्रभाव)',
      optionC: 'Light Wave Polarization (ध्रुवण)',
      optionD: 'Electromagnetic Wave Refraction',
      correctAnswer: 'B',
      explanation: 'The Photoelectric Effect (explained by Einstein in 1905) demonstrates that light behaves as packets of energy (photons), directly validating the quantum particle nature of light, which wave theory fails to explain.',
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else {
    // Lenz's Law
    return {
      id,
      questionText: `Lenz's Law of Electromagnetic Induction is a direct manifestation of which physical conservation law? / विद्युत चुंबकीय प्रेरण के लिए लेन्ज़ का नियम किस भौतिक संरक्षण कानून की प्रत्यक्ष पुष्टि करता है?`,
      optionA: 'Conservation of Linear Momentum',
      optionB: 'Conservation of Electric Charge',
      optionC: 'Conservation of Total Energy (ऊर्जा संरक्षण का नियम)',
      optionD: 'Conservation of Total Angular Momentum',
      correctAnswer: 'C',
      explanation: "Lenz's Law states that the direction of induced current always opposes the change in magnetic flux that produced it. This is a direct consequence of the Law of Conservation of Energy, ensuring you cannot generate electrical energy without doing mechanical work.",
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  }
}

function generateChemistryQuestion(testIdx: number, qIdx: number, category: string): Question {
  const id = `proc_chem_t${testIdx}_q${qIdx}`;
  const templateType = qIdx;
  
  if (templateType === 1) {
    // Molarity calculations
    const grams = 4 * (2 + (testIdx % 8)); // Multiples of 4 (ideal for NaOH = 40g/mol)
    const moles = grams / 40;
    const volMl = 250 + (testIdx % 3) * 250; // 250, 500, 750 mL
    const molarity = (moles / (volMl / 1000)).toFixed(2);
    
    return {
      id,
      questionText: `What is the molarity (M) of a solution prepared by dissolving ${grams} g of Sodium Hydroxide (NaOH, molar mass = 40 g/mol) in enough water to make exactly ${volMl} mL of solution? / ${grams} ग्राम सोडियम हाइड्रोक्साइड (NaOH) को जल में घोलकर ${volMl} mL जलीय विलयन तैयार किया गया है। विलयन की मोलरता (M) ज्ञात कीजिए।`,
      optionA: molarity + ' M',
      optionB: (parseFloat(molarity) * 2).toFixed(2) + ' M',
      optionC: (parseFloat(molarity) / 2).toFixed(2) + ' M',
      optionD: (parseFloat(molarity) + 0.5).toFixed(2) + ' M',
      correctAnswer: 'A',
      explanation: `Molecules to moles: Moles of NaOH = Mass / Molar Mass = ${grams} / 40 = ${moles} moles. Volume of solution = ${volMl} mL = ${volMl / 1000} L. Molarity = Moles / Volume(L) = ${moles} / ${volMl / 1000} = ${molarity} M. (मोलरता = विलेय के मोल / विलयन का आयतन लीटर में)`,
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 2) {
    // Ideal Gas Equation
    const p = 1 + (testIdx % 3); // 1, 2, 3 atm
    const v = 8.21 * (1 + (testIdx % 5)); // Litres
    const temp = 300; // Kelvin
    const r = 0.0821; // Gas constant
    const moles = ((p * v) / (r * temp)).toFixed(2);
    
    return {
      id,
      questionText: `How many moles of an ideal gas are present in a container of volume ${v} Liters at a pressure of ${p} atm and a temperature of 300 K? (Use R = 0.0821 L·atm/mol·K) / एक आदर्श गैस के कितने मोल होंगे यदि उसका आयतन ${v} लीटर, दाब ${p} atm और तापमान 300 K हो?`,
      optionA: (parseFloat(moles) * 1.5).toFixed(2) + ' moles',
      optionB: moles + ' moles',
      optionC: (parseFloat(moles) / 2).toFixed(2) + ' moles',
      optionD: (parseFloat(moles) + 1.2).toFixed(2) + ' moles',
      correctAnswer: 'B',
      explanation: `Using Ideal Gas equation: P * V = n * R * T => n = (P * V) / (R * T). Substituting values: n = (${p} * ${v}) / (0.0821 * 300) = ${moles} moles. (आदर्श गैस समीकरण: PV = nRT)`,
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 3) {
    // pH of strong acid
    const exp = 1 + (testIdx % 4); // 1, 2, 3, 4
    const concStr = `10⁻${exp}`;
    
    return {
      id,
      questionText: `What is the pH value of a aqueous solution of hydrochloric acid (HCl) having a hydronium ion concentration of 1 × ${concStr} M at 298 K? / 298 K पर 1 × ${concStr} M हाइड्रोक्लोरिक अम्ल (HCl) के जलीय विलयन का pH मान क्या होगा?`,
      optionA: String(14 - exp),
      optionB: String(exp),
      optionC: String(7),
      optionD: String(exp * 1.5),
      correctAnswer: 'B',
      explanation: `For strong monobasic acids like HCl, [H₃O⁺] = Acid Concentration = 10⁻${exp} M. Formula: pH = -log₁₀[H₃O⁺] = -log₁₀(10⁻${exp}) = ${exp}. (हाइड्रोक्लोरिक अम्ल एक प्रबल अम्ल है, इसलिए pH सूत्र -log[H⁺] से प्राप्त होता है।)`,
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 4) {
    // Periodic trends
    return {
      id,
      questionText: `Which of the following elements has the highest electronegativity according to Pauling Scale of electronegativity? / पॉलिंग पैमाने के अनुसार निम्नलिखित में से किस तत्व की विद्युत ऋणात्मकता (Electronegativity) सर्वाधिक होती है?`,
      optionA: 'Fluorine (F) (फ्लोरीन)',
      optionB: 'Chlorine (Cl)',
      optionC: 'Oxygen (O)',
      optionD: 'Sodium (Na)',
      correctAnswer: 'A',
      explanation: 'Fluorine is the most electronegative element in the entire periodic table, possessing an assigned value of 4.0 on the Pauling scale, due to its very small atomic radius and high nuclear charge.',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 5) {
    // Alkanes / Hybridization
    return {
      id,
      questionText: `What is the exact hybridization of carbon atoms present inside an Ethene (C₂H₄) molecule? / एथीन (C₂H₄) अणु में उपस्थित कार्बन परमाणुओं का संकरण (Hybridization) क्या होता है?`,
      optionA: 'sp',
      optionB: 'sp²',
      optionC: 'sp³',
      optionD: 'sp³d',
      correctAnswer: 'B',
      explanation: 'In Ethene (H₂C=CH₂), each Carbon atom forms 3 sigma bonds (two with hydrogen, one with another carbon) and has 0 lone pairs. Steric number = 3, which corresponds to sp² hybridization with planar triangular geometry.',
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 6) {
    // Balancing reactions
    const multiplier = 2 + (testIdx % 3); // 2, 3, 4
    return {
      id,
      questionText: `What is the coefficient of O₂ when the combustion reaction of Propane is fully balanced: C₃H₈ + X O₂ → 3 CO₂ + 4 H₂O? / जब प्रोपेन के दहन की रासायनिक प्रतिक्रिया को संतुलित किया जाता है, तो O₂ का गुणांक क्या होगा? : C₃H₈ + X O₂ → 3 CO₂ + 4 H₂O`,
      optionA: '3',
      optionB: '4',
      optionC: '5',
      optionD: '8',
      correctAnswer: 'C',
      explanation: 'On the product side, we have 3 CO₂ (6 Oxygen atoms) and 4 H₂O (4 Oxygen atoms), total 10 Oxygen atoms. To balance the reactant side, we need 5 molecules of diatomic O₂. So, coefficient X = 5.',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 7) {
    // IUPAC name of simple compound
    return {
      id,
      questionText: `What is the correct IUPAC name of the organic compound CH₃-CH(OH)-CH₂-CH₃? / कार्बनिक यौगिक CH₃-CH(OH)-CH₂-CH₃ का सही IUPAC नाम क्या है?`,
      optionA: 'Butan-1-ol',
      optionB: 'Butan-2-ol (ब्यूटेन-2-ऑल)',
      optionC: 'Propan-2-ol',
      optionD: 'Diethyl ether',
      correctAnswer: 'B',
      explanation: 'The compound is a 4-carbon chain (alkane root "butane"). The principal functional group is an alcohol (-OH), situated at carbon number 2 (closest to chain terminal). Thus, its IUPAC name is Butan-2-ol.',
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 8) {
    // Faraday's first law
    return {
      id,
      questionText: `According to Faraday's First Law of Electrolysis, the mass of any chemical substance deposited at any electrode during electrolysis is directly proportional to: / विद्युत अपघटन के फैराडे के प्रथम नियम के अनुसार, इलेक्ट्रोड पर जमा पदार्थ का द्रव्यमान सीधे किसके अनुक्रमानुपाती होता है?`,
      optionA: 'Electrolyte Concentration',
      optionB: 'Total quantity of electricity passed through the system (विद्युत आवेश / धारा की कुल मात्रा)',
      optionC: 'Electrolytic Cell Temperature',
      optionD: 'Resistance of Electrodic plates',
      correctAnswer: 'B',
      explanation: "Faraday's First Law states: m = Z * Q = Z * I * t. The mass of substance deposited (m) is directly proportional to the total electric charge (Q) that passed through the electrolyte solution.",
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 9) {
    // Coordination numbers in crystal lattices
    return {
      id,
      questionText: `What is the coordination number of atoms in a body-centered cubic (BCC) metallic crystal structure? / अंतःकेंद्रित घनीय (Body-Centered Cubic - BCC) धात्विक जालक संरचना में परमाणुओं की समन्वय संख्या (Coordination Number) क्या होती है?`,
      optionA: '6',
      optionB: '8',
      optionC: '12',
      optionD: '4',
      correctAnswer: 'B',
      explanation: 'In a body-centered cubic (BCC) unit cell, the central atom at the body center is directly in contact with 8 corner atoms of the cube, making its coordination number exactly 8.',
      difficulty: 'Hard',
      marks: 4,
      negativeMarks: 1
    };
  } else {
    // Halogen oxidising power
    return {
      id,
      questionText: `Which of the following halogens acts as the strongest oxidizing agent in aqueous chemistry? / जलीय रसायन विज्ञान में निम्नलिखित में से कौन सा हैलोजन सबसे प्रबल ऑक्सीकारक एजेंट (Oxidizing Agent) का कार्य करता है?`,
      optionA: 'Fluorine (F₂)',
      optionB: 'Chlorine (Cl₂)',
      optionC: 'Bromine (Br₂)',
      optionD: 'Iodine (I₂)',
      correctAnswer: 'A',
      explanation: 'Fluorine (F₂) has the highest positive standard reduction potential (+2.87 V), making it exceptionally easy to reduce. Thus, it is the most powerful oxidizing agent among all halogens due to its low bond dissociation energy and extremely high hydration energy.',
      difficulty: 'Hard',
      marks: 4,
      negativeMarks: 1
    };
  }
}

function generateMathsQuestion(testIdx: number, qIdx: number, category: string): Question {
  const id = `proc_math_t${testIdx}_q${qIdx}`;
  const templateType = qIdx;
  
  if (templateType === 1) {
    // AP arithmetic sum
    const a = 1 + (testIdx % 5); // First term
    const d = 2 + (testIdx % 4); // Common difference
    const n = 10; // First 10 terms
    const sum = (n / 2) * (2 * a + (n - 1) * d);
    
    return {
      id,
      questionText: `An arithmetic progression (AP) has a first term a = ${a} and common difference d = ${d}. Find the sum of its first ${n} terms. / एक समांतर श्रेणी (AP) का प्रथम पद a = ${a} और सार्व अंतर d = ${d} है। इसके प्रथम ${n} पदों का योग ज्ञात कीजिए।`,
      optionA: String(sum),
      optionB: String(sum + 20),
      optionC: String(sum - 35),
      optionD: String(sum * 2),
      correctAnswer: 'A',
      explanation: `Using the AP sum formula (समांतर श्रेणी के योग का सूत्र): S_n = (n / 2) * [2a + (n - 1)d]. Given n = ${n}, a = ${a}, d = ${d}. S_10 = 5 * [2(${a}) + 9(${d})] = 5 * [${2 * a} + ${9 * d}] = 5 * ${2 * a + 9 * d} = ${sum}.`,
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 2) {
    // Probability of Independent events
    const p1Factor = 2 + (testIdx % 3); // 2, 3, 4 lead to P(A)=0.2, 0.3, 0.4
    const p2Factor = 4 + (testIdx % 4); // 4, 5, 6, 7 lead to P(B)=0.4, 0.5, 0.6, 0.7
    const p1 = p1Factor / 10;
    const p2 = p2Factor / 10;
    const intersect = p1 * p2;
    
    return {
      id,
      questionText: `If A and B are two independent events such that P(A) = ${p1} and P(B) = ${p2}, what is the probability of their simultaneous intersection event P(A ∩ B)? / यदि A और B दो स्वतंत्र घटनाएं हैं जहाँ P(A) = ${p1} और P(B) = ${p2} है, तो उनके सर्वनिष्ठ घटना P(A ∩ B) की प्रायिकता क्या होगी?`,
      optionA: (p1 + p2 - intersect).toFixed(2),
      optionB: intersect.toFixed(2),
      optionC: (p1 / p2).toFixed(2),
      optionD: '0.00',
      correctAnswer: 'B',
      explanation: `For independent events A and B, the intersection probability is simply the product of their individual probabilities (स्वतंत्र घटनाओं के लिए): P(A ∩ B) = P(A) * P(B) = ${p1} * ${p2} = ${intersect.toFixed(2)}.`,
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 3) {
    // Determinant of a 2x2 matrix
    const a = 1 + (testIdx % 4);
    const b = 2 + (testIdx % 3);
    const c = 3 + (testIdx % 2);
    const d = 5 + (testIdx % 5);
    const det = a * d - b * c;
    
    return {
      id,
      questionText: `For a 2x2 matrix A = [[${a}, ${b}], [${c}, ${d}]], find the determinant value of matrix A, i.e., det(A). / एक 2x2 आव्यूह A = [[${a}, ${b}], [${c}, ${d}]] का सारणिक मान det(A) ज्ञात करें।`,
      optionA: String(det + 8),
      optionB: String(det),
      optionC: String(-det),
      optionD: String(a * b + c * d),
      correctAnswer: 'B',
      explanation: `The determinant of a 2x2 matrix [[a, b], [c, d]] is computed as (सारणिक का सूत्र): det(A) = a*d - b*c. Here, det = (${a} * ${d}) - (${b} * ${c}) = ${a * d} - ${b * c} = ${det}.`,
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 4) {
    // Limits
    const limitPoint = 2 + (testIdx % 4); // 2, 3, 4, 5
    const sqVal = limitPoint * limitPoint;
    const ans = limitPoint * 2;
    
    return {
      id,
      questionText: `Evaluate the mathematical calculus limit: lim (x → ${limitPoint}) of [ (x² - ${sqVal}) / (x - ${limitPoint}) ]. / सीमा मान (Limit) ज्ञात कीजिए: lim (x → ${limitPoint}) [ (x² - ${sqVal}) / (x - ${limitPoint}) ]`,
      optionA: String(ans),
      optionB: '0',
      optionC: 'Undefined (अपरिभाषित)',
      optionD: String(limitPoint),
      correctAnswer: 'A',
      explanation: `Direct substitution leads to the indeterminate form 0/0. Factoring the numerator gives (x² - ${sqVal}) = (x - ${limitPoint})(x + ${limitPoint}). Cancelling the common factor (x - ${limitPoint}) for x ≠ ${limitPoint}, we get lim (x → ${limitPoint}) [ x + ${limitPoint} ] = ${limitPoint} + ${limitPoint} = ${ans}.`,
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 5) {
    // Trigonometry identity
    return {
      id,
      questionText: `What is the algebraic representation of the double angle identity cos(2θ)? / द्विगुण कोण सूत्र cos(2θ) का बीजगणितीय रूप क्या है?`,
      optionA: '2 * sin(θ) * cos(θ)',
      optionB: 'cos²(θ) - sin²(θ) (या 2cos²θ - 1)',
      optionC: '1 + tan²(θ)',
      optionD: 'cos²(θ) + sin²(θ)',
      correctAnswer: 'B',
      explanation: 'Cos(2θ) is a fundamental trigonometric identity equal to cos²(θ) - sin²(θ), which can also be written in other equivalent formats: 2cos²(θ) - 1 or 1 - 2sin²(θ). Format A is sin(2θ).',
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 6) {
    // Linear Equations / Pair condition
    return {
      id,
      questionText: `A pair of linear equations a₁x + b₁y + c₁ = 0 and a₂x + b₂y + c₂ = 0 has "infinitely many solutions" if it satisfies which algebraic ratio? / दो चर वाले रेखीय समीकरण युग्म के "अपरिमित रूप से अनेक हल" (Infinitely many solutions) होने की शर्त क्या है?`,
      optionA: 'a₁/a₂ ≠ b₁/b₂',
      optionB: 'a₁/a₂ = b₁/b₂ ≠ c₁/c₂',
      optionC: 'a₁/a₂ = b₁/b₂ = c₁/c₂ (समानुपाती)',
      optionD: 'a₁ * a₂ + b₁ * b₂ = 0',
      correctAnswer: 'C',
      explanation: 'If a₁/a₂ = b₁/b₂ = c₁/c₂, the lines represented by both equations are coincident, meaning they share an infinite number of common intersecting points (infinitely many solutions). Option B represents parallel lines (no solution).',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 7) {
    // Simple derivative of polynomial
    const power = 3 + (testIdx % 3); // 3, 4, 5
    const coeff = 2 + (testIdx % 4); // 2, 3, 4, 5
    const derivativePower = power - 1;
    const derivativeCoeff = coeff * power;
    
    return {
      id,
      questionText: `Find the derivative (d/dx) of the function f(x) = ${coeff} * x^${power} with respect to variable x. / x के सापेक्ष फलन f(x) = ${coeff} * x^${power} का अवकलन (Derivative) क्या होगा?`,
      optionA: `${derivativeCoeff} * x^${derivativePower}`,
      optionB: `${coeff} * x^${derivativePower}`,
      optionC: `${power} * x^${derivativePower}`,
      optionD: `${derivativeCoeff} * x^${power}`,
      correctAnswer: 'A',
      explanation: `Using the power rule of differentiation (अवकलन के घात नियम): d/dx [k * x^n] = k * n * x^(n-1). Here, k = ${coeff} and n = ${power}. Hence, f'(x) = ${coeff} * ${power} * x^(${power}-1) = ${derivativeCoeff} * x^${derivativePower}.`,
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 8) {
    // Standard Integration
    return {
      id,
      questionText: `What is the indefinite integral formula of 1 / x with respect to x (for x ≠ 0)? / x के सापेक्ष 1/x का अनिश्चित समाकलन (Indefinite Integral) क्या होता है?`,
      optionA: '-1 / x²',
      optionB: 'ln|x| + C (प्राकृतिक लघुगणक)',
      optionC: 'e^x + C',
      optionD: 'x + C',
      correctAnswer: 'B',
      explanation: 'Since the derivative of the natural log function ln|x| is exactly 1/x, the Fundamental Theorem of Calculus dictates that the indefinite integral of 1/x dx is ln|x| + C, where C is the integration constant.',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 9) {
    // Standard Quadratic Roots Sum
    const a = 1;
    const b = -((2 + (testIdx % 6)) * 2); // Sum of roots
    const c = 3 + (testIdx % 4);
    
    return {
      id,
      questionText: `If α and β are the roots of the quadratic equation x² + (${b})x + ${c} = 0, what is the value of the sum of roots (α + β)? / यदि α और β द्विघात समीकरण x² + (${b})x + ${c} = 0 के मूल हैं, तो मूलों का योगफल (α + β) क्या होगा?`,
      optionA: String(b),
      optionB: String(-b),
      optionC: String(c),
      optionD: String(-c),
      correctAnswer: 'B',
      explanation: `For a standard quadratic equation ax² + bx + c = 0, the sum of roots is given by (मूलों का योग): α + β = -b / a. Here, a = 1 and b = ${b}. Thus, α + β = -(${b}) / 1 = ${-b}.`,
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else {
    // Geometric coordinates distance
    const x1 = testIdx % 5;
    const y1 = testIdx % 4;
    const x2 = x1 + 3;
    const y2 = y1 + 4;
    // (x2-x1)^2 + (y2-y1)^2 = 3^2 + 4^2 = 9 + 16 = 25. sqrt(25) = 5.
    
    return {
      id,
      questionText: `Calculate the distance between two points in coordinate geometry: P(${x1}, ${y1}) and Q(${x2}, ${y2}). / निर्देशांक ज्यामिति में बिंदुओं P(${x1}, ${y1}) और Q(${x2}, ${y2}) के बीच की दूरी ज्ञात करें।`,
      optionA: '5 units (इकाई)',
      optionB: '7 units',
      optionC: '25 units',
      optionD: '12 units',
      correctAnswer: 'A',
      explanation: `Using the Distance Formula (दूरी का सूत्र): d = √[(x₂ - x₁)² + (y₂ - y₁)²]. Here, x₂ - x₁ = ${x2} - ${x1} = 3 and y₂ - y₁ = ${y2} - ${y1} = 4. Distance d = √[3² + 4²] = √[9 + 16] = √25 = 5 units.`,
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  }
}

function generateBiologyQuestion(testIdx: number, qIdx: number, category: string): Question {
  const id = `proc_bio_t${testIdx}_q${qIdx}`;
  const templateType = qIdx;
  
  if (templateType === 1) {
    // Mendel heterozygous percentage
    return {
      id,
      questionText: `In a classical Mendelian monohypbrid cross of pea plants (Tt × Tt), what is the expected percentage of plants showing homozygous dwarf phenotype (tt) in the F2 offspring generation? / मटर के पौधों के एक संकरण (Tt × Tt) में, F2 संतति पीढ़ी में समयुग्मजी बौने प्रारूप (homozygous dwarf - tt) वाले पौधों का संभावित प्रतिशत क्या होगा?`,
      optionA: '50%',
      optionB: '25% (एक चौथाई)',
      optionC: '75%',
      optionD: '100%',
      correctAnswer: 'B',
      explanation: 'Crossing heterozygous plants Tt × Tt leads to a genotypic distribution of 1 TT (homozygous tall) : 2 Tt (heterozygous tall) : 1 tt (homozygous dwarf). Hence, the frequency of homozygous dwarf (tt) is 1/4 or exactly 25%.',
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 2) {
    // Cell energy center
    return {
      id,
      questionText: `Which double-membrane bound eukaryotic cell organelle is widely referred to as the "Powerhouse of the Cell"? / किस दोहरी झिल्ली वाले यूकेरियोटिक कोशिकांग को "कोशिका का ऊर्जाघर (पावरहाउस)" कहा जाता है?`,
      optionA: 'Chloroplast',
      optionB: 'Mitochondrion (माइटोकॉन्ड्रिया)',
      optionC: 'Golgi Apparatus',
      optionD: 'Nucleolus',
      correctAnswer: 'B',
      explanation: "Mitochondria are the primary centers for aerobic cellular respiration, containing the respiratory enzymes and electron transport chains that synthesize ATP (adenosine triphosphate) molecules, which serves as the cell's energetic currency.",
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 3) {
    // Photosynthesis pigment
    return {
      id,
      questionText: `Which mineral metal ion core forms the chemical coordination center of a Chlorophyll pigment molecule? / क्लोरोफिल वर्णक अणु के रासायनिक संयोजन केंद्र में कौन सा खनिज धातु आयन विद्यमान रहता है?`,
      optionA: 'Iron (Fe) / आयरन',
      optionB: 'Magnesium (Mg) / मैग्नीशियम',
      optionC: 'Calcium (Ca)',
      optionD: 'Zinc (Zn)',
      correctAnswer: 'B',
      explanation: 'Magnesium acts as the central metal ion in the porphyrin ring structure of chlorophyll molecules, similar to iron in hemoglobin. It is crucial for capturing light solar energy during photosynthesis.',
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 4) {
    // Blood types universal acceptor
    return {
      id,
      questionText: `Which ABO human blood group contains no antibodies against antigens A and B, and is therefore classified as the "Universal Recipient"? / मानव शरीर में कौन सा रक्त समूह Antigens A और B के प्रति कोई एंटीबॉडी नहीं रखता, और इसलिए इसे "सार्वभौमिक प्राप्तकर्ता" कहा जाता है?`,
      optionA: 'O-Negative (O-)',
      optionB: 'AB-Positive (AB+)',
      optionC: 'A-Positive (A+)',
      optionD: 'B-Positive (B+)',
      correctAnswer: 'B',
      explanation: 'Blood group AB-Positive (AB+) possesses both Antigen A and Antigen B on red cells, but has no antibodies in blood plasma. Thus, AB+ individuals can safely receive red blood cells from any blood type. (Universal donor is O-Negative).',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 5) {
    // Human hormone blood glucose
    return {
      id,
      questionText: `Which hormone, secreted by the beta cells of islets of Langerhans in the pancreas, primarily acts to lower blood glucose levels? / अग्न्याशय की लैंगरहैंस की द्वीपिकाओं की बीटा कोशिकाओं द्वारा स्रावित कौन सा हार्मोन मुख्य रूप से रक्त में शर्करा (ग्लूकोज) के स्तर को कम करता है?`,
      optionA: 'Glucagon (ग्लूकागन)',
      optionB: 'Insulin (इंसुलिन)',
      optionC: 'Adrenaline',
      optionD: 'Thyroxine',
      correctAnswer: 'B',
      explanation: 'Insulin is secreted by pancreatic beta cells to facilitate cellular glucose uptake and glycogen storage, lowering blood sugar levels. Glucagon promotes glycogenolysis, raising blood sugar levels.',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 6) {
    // DNA replication translation
    return {
      id,
      questionText: `What is the correct scientific term used to describe the biological process where an mRNA sequence is read to synthesize proteins inside ribosomes? / किस जैविक प्रक्रिया के अंतर्गत संदेशवाहक आरएनए (mRNA) अनुक्रम को पढ़कर राइबोसोम में प्रोटीन का संश्लेषण किया जाता है?`,
      optionA: 'Transcription (अनुलेखन)',
      optionB: 'Translation (अनुवादन / ट्रांसलेशन)',
      optionC: 'Replication (द्विगुणन)',
      optionD: 'Mutation (उत्परिवर्तन)',
      correctAnswer: 'B',
      explanation: 'Transcription is the creation of mRNA from DNA. Translation is the decoding of mRNA inside ribosomes to assemble specified amino acid sequences into active proteins.',
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 7) {
    // Chromosomes count
    return {
      id,
      questionText: `How many sets of autosomes (non-sex chromosomes) are present in a normal diploid human somatic cell? / एक सामान्य मानव कायिक कोशिका में ऑटोसोम (अलिंग गुणसूत्र) के कुल कितने जोड़े उपस्थित होते हैं?`,
      optionA: '23 pairs',
      optionB: '22 pairs (22 जोड़े)',
      optionC: '1 pair',
      optionD: '46 pairs',
      correctAnswer: 'B',
      explanation: 'Diploid human cells contain 46 chromosomes (23 pairs). Out of these, 22 pairs are autosomes (common to both sexes) and 1 pair comprises sex chromosomes (XX or XY).',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 8) {
    // Double heart circulation
    return {
      id,
      questionText: `In which organ of the human body does deoxygenated blood receive exchange of oxygen to become oxygenated blood? / मानव शरीर के किस अंग में विऑक्सीजनित रक्त (Deoxygenated blood) ऑक्सीजन प्राप्त करके ऑक्सीजनित रक्त बनता है?`,
      optionA: 'Heart (हृदय)',
      optionB: 'Lungs (फेफड़े / फुफ्फुस)',
      optionC: 'Kidneys (वृक्क)',
      optionD: 'Liver (यकृत)',
      correctAnswer: 'B',
      explanation: 'Deoxygenated blood is pumped from the right ventricle of the heart via pulmonary arteries to the lungs. In the pulmonary alveoli, carbon dioxide is exhaled and fresh oxygen is absorbed, producing oxygenated blood.',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 9) {
    // Plant transpiration stomata
    return {
      id,
      questionText: `The loss of excess water in the form of water vapor from the aerial parts of plants is known as: / पौधों के वायवीय भागों से जल का वाष्प के रूप में बाहर निकलना क्या कहलाता है?`,
      optionA: 'Translocation (स्थानांतरण)',
      optionB: 'Transpiration (वाष्पोत्सर्जन)',
      optionC: 'Respiration (श्वसन)',
      optionD: 'Osmosis (परासरण)',
      correctAnswer: 'B',
      explanation: 'Transpiration is the evaporative loss of water from plant leaves and stems, primarily through microscopic pores called stomata. It also creates pull to draw nutrients from soil.',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else {
    // Ecology consumers
    return {
      id,
      questionText: `In an ecology pyramid of energy, according to Lindeman's Ten Percent Rule, what proportion of total energy is successfully transferred to the next trophic level? / पारिस्थितिक ऊर्जा पिरामिड में, लिंडेमैन के 10 प्रतिशत नियम के अनुसार, कितनी ऊर्जा अगले पोषण स्तर (Trophic Level) में सफलतापूर्वक स्थानांतरित होती है?`,
      optionA: '100%',
      optionB: '10% (दस प्रतिशत)',
      optionC: '90%',
      optionD: '1%',
      correctAnswer: 'B',
      explanation: "Lindeman's 10% law state that during energy transfer in food chains, only about 10% of the organic energy is converted to biomass in the next trophic level; the remaining 90% is lost as metabolic heat.",
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  }
}

function generateSocialScienceQuestion(testIdx: number, qIdx: number): Question {
  const id = `proc_soc_t${testIdx}_q${qIdx}`;
  const templateType = qIdx;
  
  if (templateType === 1) {
    return {
      id,
      questionText: `Who presided over the historic Lahore Congress session in December 1929 where the resolution for "Purna Swaraj" (Complete Independence) was passed? / दिसंबर 1929 में हुई ऐतिहासिक लाहौर कांग्रेस अधिवेशन की अध्यक्षता किसने की थी जिसमें "पूर्ण स्वराज" का प्रस्ताव पारित किया गया था?`,
      optionA: 'Mahatma Gandhi',
      optionB: 'Jawaharlal Nehru (पंडित जवाहरलाल नेहरू)',
      optionC: 'Subhas Chandra Bose',
      optionD: 'Sardar Vallabhbhai Patel',
      correctAnswer: 'B',
      explanation: 'The Lahore Congress Session of 1929 was presided over by Jawaharlal Nehru. The historic "Purna Swaraj" declaration was adopted, establishing January 26, 1930, as Independence Day.',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 2) {
    return {
      id,
      questionText: `Which sector of the Indian economy represents the highest contribution to the national GDP (Gross Domestic Product) in recent decades? / भारतीय अर्थव्यवस्था का कौन सा क्षेत्र हाल के दशकों में सकल घरेलू उत्पाद (GDP) में सर्वाधिक योगदान देता है?`,
      optionA: 'Primary Sector (Agriculture) / प्राथमिक क्षेत्र',
      optionB: 'Tertiary Sector (Services) / तृतीयक क्षेत्र (सेवा क्षेत्र)',
      optionC: 'Secondary Sector (Manufacturing) / द्वितीयक क्षेत्र',
      optionD: 'Quaternary Sector',
      correctAnswer: 'B',
      explanation: 'The Tertiary or Service sector has emerged as the highest contributor to GDP in India, accounting for over 50% of the total economic output, although agriculture still employs the largest share of population.',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 3) {
    return {
      id,
      questionText: `Which critical environmental treaty was signed at the historic Earth Summit held in Rio de Janeiro, Brazil in June 1992? / जून 1992 में ब्राजील के रियो डी जेनेरो में आयोजित ऐतिहासिक पृथ्वी शिखर सम्मेलन में किस महत्वपूर्ण घोषणा पर हस्ताक्षर किए गए थे?`,
      optionA: 'Kyoto Protocol',
      optionB: 'Agenda 21 (एजेंडा 21)',
      optionC: 'Montreal Protocol',
      optionD: 'Paris Agreement',
      correctAnswer: 'B',
      explanation: 'The United Nations Conference on Environment and Development (UNCED) in Rio, 1992 adopted "Agenda 21", a comprehensive bluebook for global actions to achieve sustainable development in the 21st century.',
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 4) {
    return {
      id,
      questionText: `What type of soil, rich in iron oxides, is formed as a result of intense leaching due to heavy tropical rainfall? / अत्यधिक उष्णकटिबंधीय वर्षा के कारण होने वाले तीव्र निक्षालन (Leaching) के परिणामस्वरूप किस प्रकार की मिट्टी का निर्माण होता है, जो आयरन ऑक्साइड से समृद्ध होती है?`,
      optionA: 'Alluvial Soil',
      optionB: 'Laterite Soil (लेटराइट मिट्टी)',
      optionC: 'Black Soil',
      optionD: 'Arid Soil',
      correctAnswer: 'B',
      explanation: 'Laterite soil is formed in tropical areas receiving heavy rainfall. Intense rain washes away soluble silica and clay, leaving behind iron oxides, making it reddish and porous (Laterite, meaning brick in Latin).',
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else {
    // Power sharing
    return {
      id,
      questionText: `In democratic power-sharing, the horizontal distribution of power involves separating governance responsibilities among: / लोकतांत्रिक सत्ता की साझेदारी में, सत्ता का क्षैतिज वितरण (Horizontal distribution) किन अंगों के बीच होता है?`,
      optionA: 'Central, State, and Local Governments',
      optionB: 'Legislature, Executive, and Judiciary (विधायिका, कार्यपालिका और न्यायपालिका)',
      optionC: 'Different social, religious, and linguistic groups',
      optionD: 'Ruling coalition parties and opposition alliances',
      correctAnswer: 'B',
      explanation: 'Horizontal distribution shares power among organs of government at the same level: the Legislature (makes laws), the Executive (enforces laws), and the Judiciary (interprets laws). This places checks and balances in democracy.',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  }
}

function generateEnglishQuestion(testIdx: number, qIdx: number): Question {
  const id = `proc_eng_t${testIdx}_q${qIdx}`;
  const templateType = qIdx;
  
  if (templateType === 1) {
    return {
      id,
      questionText: `Choose the correct lexical connector/preposition: "The young boy apologized ________ the damage caused to the neighbor's property."`,
      optionA: 'on',
      optionB: 'for (के लिए)',
      optionC: 'at',
      optionD: 'with',
      correctAnswer: 'B',
      explanation: "The verb 'apologize' is transitive towards action and takes 'for' to represent the reason for which regret is being expressed. APOLOGIZE FOR [SOMETHING].",
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 2) {
    return {
      id,
      questionText: `Identify the correct passive voice version of the sentence: "The project manager will inaugurate the science exhibition on Monday."`,
      optionA: 'The science exhibition is inaugurated on Monday by the project manager.',
      optionB: 'The science exhibition will be inaugurated on Monday by the project manager.',
      optionC: 'The science exhibition was being inaugurated by the project manager.',
      optionD: 'The project manager had been inaugurating the exhibition on Monday.',
      correctAnswer: 'B',
      explanation: "Active sentence is in Simple Future ('will inaugurate'). Passive converts 'will + verb' into 'will be + V3 (past participle form of inaugurate)', which is 'will be inaugurated'.",
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 3) {
    return {
      id,
      questionText: `Identify the correct indirect speech of: She said to me, "Do you know where the physics laboratory is located?"`,
      optionA: 'She said to me that whether I knew where the physics laboratory is located.',
      optionB: 'She asked me if I knew where the physics laboratory was located.',
      optionC: 'She asked me that did I knew where the physics laboratory was located.',
      optionD: 'She told me if I know where the physics laboratory is located.',
      correctAnswer: 'B',
      explanation: "In indirect question transformation, reporting verb 'said to' changes to 'asked', question indicator takes 'if' or 'whether', and tense transitions to Simple Past ('know' -> 'knew', 'is' -> 'was').",
      difficulty: 'Hard',
      marks: 4,
      negativeMarks: 1
    };
  } else {
    return {
      id,
      questionText: `Complete the sentence with correct subject-verb agreement: "Either the classroom monitor or the subject teachers _______ present in the assembly hall right now."`,
      optionA: 'was',
      optionB: 'are (हैं - बहुवचन)',
      optionC: 'is',
      optionD: 'has',
      correctAnswer: 'B',
      explanation: "Rule of Proximity: When two subjects are connected by 'either... or' or 'neither... nor', the verb agrees with the closer subject. 'Subject teachers' is plural, so it requires plural verb 'are'.",
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  }
}

function generateHindiQuestion(testIdx: number, qIdx: number): Question {
  const id = `proc_hin_t${testIdx}_q${qIdx}`;
  const templateType = qIdx;
  
  if (templateType === 1) {
    return {
      id,
      questionText: `'लम्बोदर' (लम्बा है उदर जिनका अर्थात् गणेश जी) शब्द में कौन सा समास प्रयुक्त हुआ है?`,
      optionA: 'द्वंद्व समास',
      optionB: 'बहुव्रीहि समास (Bahuvrihi Samas)',
      optionC: 'द्विगु समास',
      optionD: 'तत्पुरुष समास',
      correctAnswer: 'B',
      explanation: 'बहुव्रीहि समास में कोई भी पद प्रधान नहीं होता वरन् दोनों पद मिलकर किसी तीसरे स्वतंत्र विशेष अर्थ की ओर संकेत करते हैं। यहाँ लम्बोदर श्री गणेश जी को दर्शाता है।',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 2) {
    return {
      id,
      questionText: `निम्नलिखित में से कौन सा शब्द बादल (Cloud) का सही पर्यायवाची शब्द है?`,
      optionA: 'नीरज (जलज)',
      optionB: 'जलद (Jalad / बादल)',
      optionC: 'पंकज',
      optionD: 'किरण',
      correctAnswer: 'B',
      explanation: 'जलद (जल देने वाला) बादल का पर्यायवाची शब्द है। जबकि नीरज, पंकज और जलज कमल के पर्यायवाची होते हैं।',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  } else if (templateType === 3) {
    return {
      id,
      questionText: `तुलसीदास जी द्वारा रचित 'रामचरितमानस' मुख्य रूप से किस भाषा शैली में लिखी गई है?`,
      optionA: 'अवधी भाषा (Awadhi)',
      optionB: 'ब्रजभाषा',
      optionC: 'खड़ी बोली',
      optionD: 'संस्कृत',
      correctAnswer: 'A',
      explanation: 'गोस्वामी तुलसीदास जी ने रामचरितमानस महाकाव्य की रचना अवधी भाषा में की है, जबकि उनके विनय पत्रिका आदि पद ब्रजभाषा में हैं।',
      difficulty: 'Medium',
      marks: 4,
      negativeMarks: 1
    };
  } else {
    return {
      id,
      questionText: `'चोर की दाढ़ी में तिनका' इस प्रसिद्ध मुहावरे/लोकोक्ति का सही अर्थ क्या होता है?`,
      optionA: 'चोर की दाढ़ी में तिनके का होना',
      optionB: 'दोषी व्यक्ति सदैव शंकित और भयभीत रहता है (Guilty mind is always suspicious)',
      optionC: 'दाढ़ी कटवा लेना',
      optionD: 'अपराधी को तुरंत पकड़ लेना',
      correctAnswer: 'B',
      explanation: 'इस लोकोक्ति का वास्तविक और सांकेतिक अर्थ है कि जिसने अपराध किया होता है, वह खुद अपनी हरकतों से डरा रहता है और सदैव शंकित रहता है।',
      difficulty: 'Easy',
      marks: 4,
      negativeMarks: 1
    };
  }
}

// Generate the massive database of tests of 10 questions each
export function generateProceduralTests(): Test[] {
  const tests: Test[] = [];
  
  const categories: ('Class 10' | 'Class 11' | 'Class 12' | 'JEE' | 'NEET')[] = [
    'Class 10',
    'Class 11',
    'Class 12',
    'JEE',
    'NEET'
  ];
  
  const categorySubjects: Record<string, string[]> = {
    'Class 10': ['Science', 'Maths', 'Social Science', 'English', 'Hindi'],
    'Class 11': ['Physics', 'Chemistry', 'Maths', 'Biology'],
    'Class 12': ['Physics', 'Chemistry', 'Maths', 'Biology'],
    'JEE': ['Physics', 'Chemistry', 'Maths'],
    'NEET': ['Physics', 'Chemistry', 'Biology']
  };

  const getHinglishSubjectTitle = (subject: string): string => {
    const maps: Record<string, string> = {
      'Science': 'Science (विज्ञान)',
      'Maths': 'Maths (गणित)',
      'Social Science': 'Social Science (सामाजिक विज्ञान)',
      'English': 'English (अंग्रेजी)',
      'Hindi': 'Hindi (हिंदी)',
      'Physics': 'Physics (भौतिक विज्ञान)',
      'Chemistry': 'Chemistry (रसायन विज्ञान)',
      'Biology': 'Biology (जीव विज्ञान)'
    };
    return maps[subject] || subject;
  };

  // For each category and its subjects...
  categories.forEach((cat) => {
    const subjects = categorySubjects[cat] || [];
    subjects.forEach((sub) => {
      // Generate exactly 50 tests for this subject
      for (let i = 11; i <= 60; i++) {
        const questions: Question[] = [];
        
        // Generate exactly 10 questions of 4 marks each (total 40 marks)
        for (let q = 1; q <= 10; q++) {
          let questionObj: Question;
          
          if (sub === 'Physics') {
            questionObj = generatePhysicsQuestion(i, q, cat);
          } else if (sub === 'Chemistry') {
            questionObj = generateChemistryQuestion(i, q, cat);
          } else if (sub === 'Maths') {
            questionObj = generateMathsQuestion(i, q, cat);
          } else if (sub === 'Biology') {
            questionObj = generateBiologyQuestion(i, q, cat);
          } else if (sub === 'Science') {
            // Mix physics, chemistry, biology questions or assign based on odd/even sequence
            if (q % 3 === 1) questionObj = generatePhysicsQuestion(i, q, cat);
            else if (q % 3 === 2) questionObj = generateChemistryQuestion(i, q, cat);
            else questionObj = generateBiologyQuestion(i, q, cat);
          } else if (sub === 'Social Science') {
            questionObj = generateSocialScienceQuestion(i, q);
          } else if (sub === 'English') {
            questionObj = generateEnglishQuestion(i, q);
          } else if (sub === 'Hindi') {
            questionObj = generateHindiQuestion(i, q);
          } else {
            // General Science default
            questionObj = generatePhysicsQuestion(i, q, cat);
          }
          
          // Overwrite unique ID to prevent overlap
          questionObj.id = `proc_${cat.replace(' ', '_')}_${sub.toLowerCase()}_t${i}_q${q}`;
          questions.push(questionObj);
        }
        
        const difficulties: ('Easy' | 'Medium' | 'Hard')[] = ['Easy', 'Medium', 'Hard'];
        const diff = difficulties[(i + sub.length) % 3];
        const chapterNum = ((i * 3) % 15) + 1;
        
        const testObj: Test = {
          id: `pt_${cat.toLowerCase().replace(' ', '')}_${sub.toLowerCase()}_t${i}`,
          title: `${cat} ${sub}: Practice Paper ${i - 10} (${getHinglishSubjectTitle(sub)} - अभ्यास पत्र ${i - 10})`,
          category: cat,
          subject: sub,
          chapter: `Topic Chapter ${chapterNum}: Extensive Core Syllabus Coverage`,
          difficulty: diff,
          questionsCount: 10,
          totalMarks: 40,
          durationMinutes: 12,
          questions: questions
        };
        
        tests.push(testObj);
      }
    });
  });
  
  return tests;
}
