export interface Question {
  id: string;
  questionText: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  correctAnswer: 'A' | 'B' | 'C' | 'D';
  explanation: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  marks: number;
  negativeMarks: number;
}

export interface Test {
  id: string;
  title: string;
  category: 'Class 10' | 'Class 11' | 'Class 12' | 'JEE' | 'NEET';
  subject: string;
  chapter: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  questionsCount: number;
  totalMarks: number;
  durationMinutes: number;
  questions: Question[];
}

export interface Attempt {
  id: string;
  testId: string;
  testTitle: string;
  category: string;
  subject: string;
  date: string;
  score: number;
  maxScore: number;
  percentage: number;
  correctAnswers: number;
  wrongAnswers: number;
  skippedAnswers: number;
  totalQuestions: number;
  selectedAnswers: Record<string, 'A' | 'B' | 'C' | 'D' | null>;
  markedForReview: Record<string, boolean>;
}

export interface GuidanceVideo {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  videoUrl: string;
}

export interface GuidancePoster {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
}
