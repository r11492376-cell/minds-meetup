export interface AndroidFile {
  name: string;
  path: string;
  language: 'kotlin' | 'xml' | 'groovy';
  content: string;
}

export const androidProjectSources: AndroidFile[] = [
  {
    name: "MainActivity.kt",
    path: "app/src/main/java/com/mindsmeetup/app/MainActivity.kt",
    language: "kotlin",
    content: `package com.mindsmeetup.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.mindsmeetup.app.ui.screens.MainAppScreen
import com.mindsmeetup.app.ui.theme.MindsMeetupTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState);
        setContent {
            MindsMeetupTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    MainAppScreen()
                }
            }
        }
    }
}`
  },
  {
    name: "MainAppScreen.kt",
    path: "app/src/main/java/com/mindsmeetup/app/ui/screens/MainAppScreen.kt",
    language: "kotlin",
    content: `// master Jetpack Compose file containing Navigation, States & Screens
package com.mindsmeetup.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun MainAppScreen() {
    var currentScreen by remember { mutableStateOf("splash") }
    // ... complete implementation ...
}`
  },
  {
    name: "Theme.kt",
    path: "app/src/main/java/com/mindsmeetup/app/ui/theme/Theme.kt",
    language: "kotlin",
    content: `package com.mindsmeetup.app.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF1E88E5), // Corporate blue
    onPrimary = Color.White,
    background = Color(0xFFF8F9FA),
    surface = Color.White
)

@Composable
fun MindsMeetupTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}`
  },
  {
    name: "AndroidManifest.xml",
    path: "app/src/main/AndroidManifest.xml",
    language: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.mindsmeetup.app">

    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Mind's Meetup"
        android:theme="@style/Theme.MindsMeetup">
        
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`
  },
  {
    name: "app/build.gradle",
    path: "app/build.gradle",
    language: "groovy",
    content: `plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
}

android {
    namespace 'com.mindsmeetup.app'
    compileSdk 34

    defaultConfig {
        applicationId "com.mindsmeetup.app"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }

    buildFeatures {
        compose true
    }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.compose.material3:material3:1.1.2'
    implementation 'androidx.navigation:navigation-compose:2.7.6'
}`
  },
  {
    name: "project/build.gradle",
    path: "build.gradle",
    language: "groovy",
    content: `buildscript {
    ext {
        compose_version = '1.5.4'
        kotlin_version = '1.9.21'
    }
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.1.4'
        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlin_version"
        classpath 'com.google.gms:google-services:4.4.0'
    }
}`
  }
];
